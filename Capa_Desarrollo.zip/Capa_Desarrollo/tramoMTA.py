import geopandas as gpd
from shapely.geometry import Point, LineString
import math
import time
import numpy as np 

#------VARIABLES DE COMPONENTES-----
total_componentes_poste=0
total_movidos=0 
total_faltantes=0
#------Listas
lista_componentes_postes=[]
lista_componentes_movidos=[]
lista_componentes_faltantes=[]
def get_angle_of_line(line): 
    # Asegurarse de que la geometría sea una LineString
    if not isinstance(line, LineString):
        raise ValueError("La entrada debe ser una instancia de LineString")

    # Obtener las coordenadas de los puntos finales de la línea
    x1, y1 = line.coords[0]
    x2, y2 = line.coords[-1]

    # Calcular el ángulo en radianes
    angle_radians = math.atan2(y2 - y1, x2 - x1)
    
    # Convertir el ángulo a grados
    angle_degrees = math.degrees(angle_radians)
    return angle_degrees

# Crear una función para calcular el ángulo entre una línea y un punto
def angle_line_and_point(line, point):
    # Encontrar el punto en la línea más cercano al punto dado
    nearest_point_on_line = line.interpolate(line.project(point)) 
    # Calcular el ángulo entre la línea y el punto usando la función atan2
    angle_radians = math.atan2(nearest_point_on_line.y - point.y, nearest_point_on_line.x - point.x)
    # Convertir el ángulo a grados
    angle_degrees = math.degrees(angle_radians)
    return angle_degrees

# Crear una función para encontrar la línea más cercana a un punto
def encontrar_linea_mas_cercana_BTA(lineas, punto):
    # Verificar si el GeoDataFrame de líneas está vacío
    if lineas.empty:
        return None  # Retorna None si no hay líneas en el GeoDataFrame

    # Calcular la distancia entre el punto y cada línea
    lineas['distancia'] = lineas['geometry'].distance(punto)
    # Encontrar el índice de la línea con la menor distancia
    indice_linea_mas_cercana = lineas['distancia'].idxmin()
    # Obtener la geometría de la línea con la menor distancia
    linea_mas_cercana = lineas.loc[indice_linea_mas_cercana, 'geometry']

    # Verificar si la línea encontrada está vacía o si la distancia es demasiado grande
    if linea_mas_cercana.is_empty or lineas.loc[indice_linea_mas_cercana, 'distancia'] >2:
        linea_mas_cercana=lineas.loc['geometry'].values
        return linea_mas_cercana  # Retorna None si la línea encontrada no es válida

    # Devolver la geometría de la línea más cercana
    return linea_mas_cercana

# Crear una función para encontrar la línea más cercana a un punto
def encontrar_linea_mas_cercana(lineas, punto):
    # Calcular la distancia entre el punto y cada línea
    lineas['distancia'] = lineas['geometry'].distance(punto)#punto.geometry.iloc[0] 
    # Encontrar la línea con la menor distancia
    linea_mas_cercana = lineas.loc[lineas['distancia'].idxmin()]
    #print("------------->",linea_mas_cercana['OBJECTID'])
    if  linea_mas_cercana.empty:
        linea_mas_cercana=lineas.loc['geometry'].values 
    return linea_mas_cercana['geometry']

##FUNCION DE AGRUPAR UNIONES ANTIGUAS Y MOVIDAS
def funcion_combinar_geometrias_generales(shapefile_antiguas,shapefile_movidas):
    capa_antiguas= gpd.read_file(shapefile_antiguas)
    capa_movidas= gpd.read_file(shapefile_movidas)
    lista_combinados=[]
    for indexUM,movida in zip(capa_movidas['OBJECTID'],capa_movidas['geometry']):         
        for indexUA,antigua in zip(capa_antiguas['OBJECTID'],capa_antiguas['geometry']):            
            if indexUA==indexUM and antigua.coords[:]!= movida.coords[:]: 
                geometria_agrupada = {
                        'OBJECTID': indexUA,
                        'id_antigua': indexUA,
                        'id_nueva': indexUM, 
                        'coordenadas_antiguas': antigua.coords[:],
                        'coordenadas_movidas': movida.coords[:],
                }
                lista_combinados.append(geometria_agrupada)
                break
    return lista_combinados

##FUNCION DE AGRUPAR UNIONES ANTIGUAS Y MOVIDAS
def funcion_agrupar_iluminarias_antiguas_movidas(shapefile_iluminaria_antiguas,shapefile_iluminaria_movidas):
    capa_iluminaria_antiguas= gpd.read_file(shapefile_iluminaria_antiguas)
    capa_iluminaria_movidas= gpd.read_file(shapefile_iluminaria_movidas)
    lista_iluminarias_combinados=[]
    for indexUM,iluminaria_movida in zip(capa_iluminaria_movidas['OBJECTID'],capa_iluminaria_movidas['geometry']):         
        for indexUA,iluminaria_antigua in zip(capa_iluminaria_antiguas['OBJECTID'],capa_iluminaria_antiguas['geometry']):            
            if indexUA==indexUM and iluminaria_antigua.coords[:]!=iluminaria_movida.coords[:]: 
                geometria_agrupada = {
                        'id_iluminaria_antigua': indexUA,
                        'id_iluminaria_nueva': indexUM, 
                        'coordenada_iluminaria_antigua': iluminaria_antigua.coords[:],
                        'coordenada_iluminaria_movida': iluminaria_movida.coords[:],
                }
                lista_iluminarias_combinados.append(geometria_agrupada)
                break
    return lista_iluminarias_combinados

def calcular_angulo_linea(linea):
    x1, y1 = linea[0]
    x2, y2 = linea[1]

    # Calcular las diferencias en las coordenadas x e y
    dx = x2 - x1
    dy = y2 - y1

    # Calcular el ángulo utilizando atan2 y convertirlo a grados
    angulo_rad = math.atan2(dy, dx)
    angulo_grados = math.degrees(angulo_rad) 
    # Asegurarse de que el ángulo esté en el rango [0, 360)
    angulo_grados = angulo_grados % 360

    return angulo_grados 


    
def get_point_relative_positionBTA(point, line,poste): 
    # Obtener las coordenadas de los puntos inicial y final de la línea
    x1, y1 = line.coords[0]
    punto_interpolado=[]
    
    # Calcular las coordenadas del punto interpolado cercano a la línea
    punto_interpolado = line.interpolate(line.project(point))
    if not punto_interpolado:
        punto_interpolado=poste
    x2, y2 = punto_interpolado.coords[0] 

    #x2, y2 = line.coords[1]
    orientacion=''
    # Verificar si la línea es vertical, horizontal o diagonal
    if x1 == x2:
        orientacion = 'VERTICAL'
    elif y1 == y2:
        orientacion = 'HORIZONTAL'
    else:
        orientacion = 'DIAGONAL'
    # Calcula el área del triángulo formado por la línea y el punto 
    
    area = 0.5 * ((line.coords[1][0] - line.coords[0][0]) * (point.y - line.coords[0][1]) -
                  (point.x - line.coords[0][0]) * (line.coords[1][1] - line.coords[0][1]))
    # Determina la posición relativa del punto
    if area < 0: #point.x:
        return 'IZQUIERDA'
    elif area > 0: #point.x:
        return 'DERECHA'
    else: #if area == point.area: 
        position = 'ARRIBA' if point.y > min(line.coords[0][1], y2) else 'ABAJO' #line.coords[1][1]
        return position
  
 
#---------- 
def get_point_relative_position_simple(point, line,poste): 
    # Obtener las coordenadas de los puntos inicial y final de la línea
    
    punto_interpolado=[]
    punto_interpolado = line.interpolate(line.project(point))
    area=0 

    orientacion=''
    position=''

    x1, y1 = line.coords[0]
    x2, y2 = line.coords[1]
    if len(line.coords[:])==2:#Cuando la linea mt movida tiene dos vertices 
        x1, y1 = line.coords[0]
        x2, y2 = line.coords[1]  
        area = 0.5 * ((x2 - x1) * (point.y - y1) - (point.x - x1) * (y2 - y1))
    elif len(line.coords[:])!=2:

        if punto_interpolado==line.coords[0]:#--VALIDAR al inicio
            x1, y1 = line.coords[0]
            x2, y2 = line.coords[1]  
            
        elif punto_interpolado==line.coords[-1]:#--VALIDAR al final
            x1, y1 = line.coords[-1]
            x2, y2 = line.coords[-2]    

            
        if not punto_interpolado:#---SE TOMA REFERENCIA DE PUNTO POSTE----
            punto_interpolado=poste 
            x1, y1 = punto_interpolado.coords[0]
            x2, y2 = line.coords[1]  
        #position=detectar_posicion_punto_con_respecto_a_poste(point, poste) 
        area = 0.5 * ((x2 - x1) * (point.y - y1) -(point.x - x1) * (y2 - y1)) 

    # Verificar si la línea es vertical, horizontal o diagonal
    if x1 == x2:
        orientacion = 'VERTICAL'
    elif y1 == y2:
        orientacion = 'HORIZONTAL'
    else:
        orientacion = 'DIAGONAL'  
    # Determina la posición relativa del punto
    if  area < 0: #point.x:
        position =  'IZQUIERDA'
    elif    area > 0: #point.x:  orientacion in ['DIAGONAL','VERTICAL']
        position =  'DERECHA'
    elif orientacion in ['HORIZONTAL']:   
        if (point.y > min(line.coords[0][1], line.coords[1][1])):
            position= 'ARRIBA' if point.x > min(line.coords[0][0], line.coords[1][0]) else 'ABAJO' 
            #position = 'ARRIBA' if point.y > 0  else 'ABAJO' #min(y1, y2) 
    return position,orientacion

def detectar_posicion_punto_con_respecto_a_poste(punto, poste):
    x_poste, y_poste = poste.x, poste.y
    x_punto, y_punto = punto.x, punto.y
    posicion=[]

    if x_punto < x_poste:
        posicion = 'IZQUIERDA'
    elif x_punto > x_poste:
        posicion = 'DERECHA'
    else:
        posicion = 'EN EL POSTE'

    if y_punto < y_poste:
        posicion = 'ABAJO'
    elif y_punto > y_poste:
        posicion= 'ARRIBA'
    else:
        posicion= 'EN EL POSTE' 
    return posicion

#-----FUNCION CORRECCION LADO INVIRTIENDO VERTICES DE LINEA--
def get_line_point_relative_position_correcion(punto, linea,poste):    
    posicion=''
    cantidad_vertices = len(linea.coords[:])
    new_lineaMTM=[]
    orientacion=''
    linea = gpd.GeoSeries([linea])
    distances = linea.apply(lambda geom: punto.distance(geom))  
    min_distance_index = distances.idxmin() 
    if cantidad_vertices==2:#-------Linea con dos vertices o coordenadas 
        if min_distance_index == 0:#Posicion vertice INICIO interpolado en  
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index]) 
            new_lineaMTM.append(linea.iloc[0].coords[-1])    
    elif cantidad_vertices>2: #-------- numero de vertices mayor a 2 coordenadas en lineas   
        if min_distance_index == 0:#Posicion inicio vertice interpolado  
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index+1]) 
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index]) 

    linea=LineString(new_lineaMTM)  
    x1, y1 = linea.coords[0]
    x2, y2 = linea.coords[1]   
    area = 0.5 * ((linea.coords[1][0] - linea.coords[0][0]) * (punto.y - linea.coords[0][1]) -
                  (punto.x - linea.coords[0][0]) * (linea.coords[1][1] - linea.coords[0][1])) 
 
    # Crear vectores desde el punto inicial de la línea al punto y desde el punto final de la línea al punto
    vector_linea = (x2 - x1, y2 - y1)
    vector_punto = (punto.x - x1, punto.y - y1)

    # Calcular el producto cruzado
    producto_cruzado = vector_linea[0] * vector_punto[1] - vector_linea[1] * vector_punto[0]

    # Determinar la posición relativa del punto
    
    # Determinar la orientación de la línea (horizontal, vertical o diagonal)
    if x1 == x2:
        orientacion = 'VERTICAL'
    elif y1 == y2:
        orientacion = 'HORIZONTAL'
    else:
        orientacion = 'DIAGONAL'

    # Calcular la posición relativa del punto
    if orientacion in ['VERTICAL','DIAGONAL']:
        # Determina la posición relativa del punto
        if  area> 0:
            posicion= 'DERECHA'
        elif area < 0: 
            posicion= 'IZQUIERDA'

    elif orientacion == 'HORIZONTAL': 
        if (punto.y > min(linea.coords[0][1], linea.coords[1][1])):
            posicion= 'ARRIBA' if punto.x > min(linea.coords[0][0], linea.coords[1][0]) else 'ABAJO'  

    return posicion, orientacion

# ---PRINCIPAL FUNCION PARA OBTENER LA POSICION RELATIVA DEL PUNTO EN LA LINEA
def get_line_point_relative_position(punto, linea,poste): 
    posicion=''
    cantidad_vertices = len(linea.coords[:])
    new_lineaMTM=[]
    orientacion=''
    linea = gpd.GeoSeries([linea])
    distances = linea.apply(lambda geom: punto.distance(geom))  
    min_distance_index = distances.idxmin() 
    if cantidad_vertices==2:#-------Linea con dos vertices o coordenadas 
        if min_distance_index == 0:#Posicion vertice INICIO interpolado en  
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index]) 
            new_lineaMTM.append(linea.iloc[0].coords[-1])    
    elif cantidad_vertices>2: #-------- numero de vertices mayor a 2 coordenadas en lineas  
        if min_distance_index == 0:#Posicion inicio vertice interpolado  
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index]) 
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index+1]) 

    linea=LineString(new_lineaMTM)  
    x1, y1 = linea.coords[0]
    x2, y2 = linea.coords[1]   
    area = 0.5 * ((linea.coords[1][0] - linea.coords[0][0]) * (punto.y - linea.coords[0][1]) -
                  (punto.x - linea.coords[0][0]) * (linea.coords[1][1] - linea.coords[0][1])) 

    # Determinar la orientación de la línea (horizontal, vertical o diagonal)
    if x1 == x2:
        orientacion = 'VERTICAL'
    elif y1 == y2:
        orientacion = 'HORIZONTAL'
    else:
        orientacion = 'DIAGONAL'

    # Calcular la posición relativa del punto 
    if orientacion in ['VERTICAL','DIAGONAL']:

       posicion = 'IZQUIERDA' if area < x1 else 'DERECHA'

    elif orientacion == 'HORIZONTAL':
        if (punto.y > min(linea.coords[0][1], linea.coords[1][1])):
            posicion= 'ARRIBA' if punto.x > min(linea.coords[0][0], linea.coords[1][0]) else 'ABAJO' 
 
    return posicion, orientacion
 
 

def corregir_lado_vertice_lineaMT(poste, point, lado,distancia): 
    angle_radians=0
    punto_cercano = poste
    translated_point = Point(point.x - punto_cercano.x, point.y - point.y)

    if lado=="DERECHA": 
        angle_radians=2*np.pi
    elif lado=="IZQUIERDA":
        angle_radians=np.pi
    elif lado == "ABAJO": 
        angle_radians=3*(np.pi/2)
    elif lado =="ARRIBA":
        angle_radians=(np.pi/2)
    # Aplicar la rotación
    rotated_x = translated_point.x +distancia * math.cos(angle_radians) - translated_point.y * math.sin(angle_radians)
    rotated_y = translated_point.x +distancia * math.sin(angle_radians) + translated_point.y * math.cos(angle_radians) 
    # Desplazar de nuevo al punto de referencia original
    rotated_point = Point(rotated_x + punto_cercano.x, rotated_y + punto_cercano.y) 
    return rotated_point 
 
# Crear una función para calcular el ángulo entre una línea y un punto
def angle_seccionador_poste(poste,seccionador):
     
    # Calcular el ángulo entre la línea y el punto usando la función atan2
    #angle_radians = math.atan2(seccionador.y - poste.y, seccionador.x - poste.x)
    angle_radians = np.arctan2(seccionador.y - poste.y, seccionador.x - poste.x)
    # Convertir el ángulo a grados
    angle_degrees = np.degrees(angle_radians)
    return angle_degrees

def girar_componente_angulo_seccionador(poste, componente,distancia,angulo): 
    angle_radians = np.radians(angulo)

    # Calcular las coordenadas del componente con respecto al poste
    componente_x = poste.x + distancia * np.cos(angle_radians)
    componente_y = poste.y + distancia * np.sin(angle_radians)

    # Crear el nuevo componente rotado
    componente_rotado = Point(componente_x, componente_y)

    return componente_rotado
 

# FUNCION PARA CORREGIR VERTICES LINEA BTA EN CERCA DE LINEAB
#------------  VALE, PERO CONFUNDE POSTES 
def move_vertice_BT_cercanoMT(poste, point,distancia): 

    # Calcular el ángulo actual entre la línea y el punto en radianes
    punto_cercano = poste#line.interpolate(line.project(point))
    # Desplazar el punto para que el punto de referencia sea el origen
    translated_point = Point(point.x - punto_cercano.x, point.y - point.y)
    angle_radians=np.pi
    # Aplicar la rotación
    rotated_x = translated_point.x +distancia * math.cos(angle_radians) - translated_point.y * math.sin(angle_radians)
    rotated_y = translated_point.x +distancia * math.sin(angle_radians) + translated_point.y * math.cos(angle_radians) 
    # Desplazar de nuevo al punto de referencia original
    rotated_point = Point(rotated_x + punto_cercano.x, rotated_y + punto_cercano.y)

    return rotated_point   
 

#---- MOVER ILUMINARIAS EN BTA Y UNIONES
def mover_iluminaria_perpendicular_to_poste(poste, point,distanciaR): 
    #punto_cercano = line.interpolate(line.project(point)) 
    punto_cercano=poste
    angle_radians = np.arctan2( point.y -punto_cercano.y, point.x  -punto_cercano.x) 
    angulo_grados= np.degrees(angle_radians)  
    perpendicular_angle_radians=0  
    #--ANGULOS POSITIVOS
    if angulo_grados >0 and angulo_grados < 90:
        diff_union = 90-angulo_grados 
        perpendicular_angle_radians = angle_radians   - np.radians(diff_union) #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif angulo_grados> 90:
        diff_union = angulo_grados-90 
        perpendicular_angle_radians = angle_radians  + np.radians(diff_union) #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif (angulo_grados> 89 and angulo_grados<91) or (angulo_grados< -88 and angulo_grados > -91):
        perpendicular_angle_radians=angle_radians  
    elif angulo_grados < -90 :
        diff_union = angulo_grados + 90 
        perpendicular_angle_radians = angle_radians   -np.radians(diff_union)  #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif angulo_grados >-90  and angulo_grados <0:
        diff_union = 90 -angulo_grados
        perpendicular_angle_radians = angle_radians  + np.radians(-(diff_union))
       
    newX_rotado =  punto_cercano.x +distanciaR * np.cos(perpendicular_angle_radians) 
    newY_rotado =  punto_cercano.y +distanciaR * np.sin(perpendicular_angle_radians) 
    #nuevo_angulo = np.arctan2( newY_rotado -punto_cercano.y, newX_rotado  -punto_cercano.x) 
    #print(angulo_grados,"-****---ANGULO CORREGIDO Y DESPLAZADO ES ----",np.degrees(nuevo_angulo))
    return  Point(newX_rotado, newY_rotado)


def get_point_relative_position(point, line,poste): 
    # Obtener las coordenadas de los puntos inicial y final de la línea
    linea = gpd.GeoSeries([line])
    distances = linea.apply(lambda geom: point.distance(geom))
    min_distance_index = distances.idxmin() 

    punto_interpolado=linea.iloc[0].coords[min_distance_index]
    punto_interpolado=Point(punto_interpolado)
    area=0
    if len(line.coords[:])==2:#Cuando la linea mt movida tiene dos vertices 
        x1, y1 = line.coords[0]
        x2, y2 = line.coords[-1]  


    elif len(line.coords[:])!=2: 
         
        #Se interpola el vertice cercano de la mtm a el punto vertice bta
        if not punto_interpolado: 
            punto_interpolado=poste  
        x1, y1 =  punto_interpolado.coords[0] #VERTICE INTERPOLADO EN PUNTO CERCANO
        x2, y2 =  line.coords[-1]#VERTICE FINAL DE LA LINEA MT MOVIDA PARA PERPENDICULAR
        area = 0.5 * ((x2 - x1) * (point.y - y1) -
                    (point.x - x1) * (y2 - y1)) 
 
    orientacion=''
    posicion=''
    # Verificar si la línea es vertical, horizontal o diagonal
    if x1 == x2:
        orientacion = 'VERTICAL'
    elif y1 == y2:
        orientacion = 'HORIZONTAL'
    else:
        orientacion = 'DIAGONAL'  
    # Determina la posición relativa del punto
    if  area < 0: #point.x:
        posicion= 'IZQUIERDA'
    elif   area > 0: #point.x:
        posicion= 'DERECHA'
    else:
        if orientacion in ['DIAGONAL','HORIZONTAL']: 
           posicion= 'ARRIBA' if point.y > min(y1, y2) else 'ABAJO' 
    return posicion
     

def girar_componente_caso(componente,caso,poste): 
    radiante_lado=0 
    distancia=0.001
    
    if caso==1: # "DERECHA"----APLICADO
        radiante_lado= (np.pi/2)

    elif caso==2:#"IZQUIERDA" #----APLICANDO
        radiante_lado=3*(np.pi/2)  
    elif caso == 3:# ARRIBA"  
        radiante_lado= 5*np.pi/6

    elif caso ==4:#"ABAJO"
        radiante_lado=  3*np.pi/2  

    # Calcular el ángulo actual entre la línea y el punto en radianes
    punto_cercano = poste
    # Desplazar el punto para que el punto de referencia sea el origen
    translated_point = Point(componente.x - punto_cercano.x, componente.y - punto_cercano.y)
    angle_radians=radiante_lado
    # Aplicar la rotación
    rotated_x = translated_point.x +distancia * math.cos(angle_radians) - translated_point.y * math.sin(angle_radians)
    rotated_y = translated_point.x +distancia * math.sin(angle_radians) + translated_point.y * math.cos(angle_radians) 
      

    rotated_point = Point(rotated_x + punto_cercano.x, rotated_y + punto_cercano.y) 
   
    return rotated_point

def caso_radiantes(caso): 
    radiante=0
    if caso==1:
        radiante = np.pi/6
    elif caso==2:
        radiante = np.pi/4
    elif caso==3:
        radiante = np.pi/3
    elif caso==4:
        radiante = np.pi/2
    elif caso==5:
        radiante = 2*(np.pi/3)
    elif caso==6:
        radiante = 3*(np.pi/4)
    elif caso==7:
        radiante = 5*(np.pi/6)
    elif caso==8:
        radiante = np.pi
    elif caso==9:
        radiante = 7*(np.pi/6)
    elif caso==10:
        radiante = 5*(np.pi/4)
    elif caso==11:
        radiante = 4*(np.pi/3)
    elif caso==12:
        radiante = 3*(np.pi/2)
    elif caso==13:
        radiante = 5*(np.pi/3)
    elif caso==14:
        radiante = 7*(np.pi/4)
    elif caso==15:
        radiante = 11*(np.pi/6)
    elif caso==16:
        radiante = 2*(np.pi)
    return radiante


    


def es_angulo_perpendicular(punto, linea):
    # Encontrar la coordenada cercana de la línea al punto
    punto_cercano = linea.interpolate(linea.project(punto))

    # Calcular el ángulo entre la línea y el punto usando la aritmética de vectores
    vector_linea = (linea.coords[-1][0] - punto_cercano.x, linea.coords[-1][1] - punto_cercano.y)
    vector_punto = (punto.x - punto_cercano.x, punto.y - punto_cercano.y)

    producto_punto = vector_linea[0] * vector_punto[0] + vector_linea[1] * vector_punto[1]
    magnitud_linea = math.sqrt(vector_linea[0] ** 2 + vector_linea[1] ** 2)
    magnitud_punto = math.sqrt(vector_punto[0] ** 2 + vector_punto[1] ** 2)

    # Calcular el ángulo en radianes
    angulo_radianes = math.acos(producto_punto / (magnitud_linea * magnitud_punto))

    # Verificar si el ángulo es aproximadamente perpendicular (90 grados)
    es_perpendicular = math.isclose(angulo_radianes, math.pi / 2, abs_tol=1e-9)

    return es_perpendicular

def move_point_perpendicular_to_lineBajante_componente(poste, point,distancia,linea,lado,posicion_linea):  
      
    perpendicular_angle_radians=0 
    new_vertice=[]
    newX_rotado=[] 
    newY_rotado=[]
    cantidad_vertices = len(linea.coords[:]) 
    linea = gpd.GeoSeries([linea]) 
    #Distancias entre vertices y el punto
    distances = linea.apply(lambda geom: point.distance(geom))
    #Se encuentra  el index del vertice con distancia minima al punto
    min_distance_index = distances.idxmin()  
    new_lineaMTM=[] 
    punto_cercano = linea.iloc[0].coords[min_distance_index] 
    punto_cercano=Point(punto_cercano)  

    if cantidad_vertices==2:#-------Linea con dos vertices o coordenadas 
        if min_distance_index == 0: 
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index]) 
            new_lineaMTM.append(linea.iloc[0].coords[-1])    

    elif cantidad_vertices>2: #-------- numero de vertices mayor a 2 coordenadas en lineas
        if min_distance_index == 0: 
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index]) 
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index+1])

    linea=LineString(new_lineaMTM)       
    caso = 0 
    estado_perpendicular1=True
    estado_perpendicular2=True
    estado_perpendicular3=True 
    estado_perpendicular4=True
    estado_perpendicular5=True

    angulo_componente=0 
    angulo_radiante_componente= np.radians(angle_seccionador_poste(poste,point))
    perpendicular=False

    #------PRIMER CASO---
    while estado_perpendicular1: 
        caso+=1 
        radiante_caso=caso_radiantes(caso)    
        perpendicular_angle_radians =  radiante_caso   #SE SUMA EL ANGULO DEL COMPONENTE
        newX_rotado =  punto_cercano.x + distancia * np.cos(perpendicular_angle_radians) 
        newY_rotado =  punto_cercano.y + distancia * np.sin(perpendicular_angle_radians)    
        new_vertice= Point([newX_rotado,newY_rotado])   
        angulo_grados = calcular_angulo_entre_punto_y_linea(new_vertice, linea)   

        if (angulo_grados >=80 and angulo_grados<=90) :   
            angulo_componente=perpendicular_angle_radians  
            estado_perpendicular1=False 
            perpendicular=True
        elif (angulo_grados<80 and caso>16) or (angulo_grados>90 and caso>16):
            estado_perpendicular1=False 
            perpendicular=False
    
    #------SEGUNDO CASO---
    if perpendicular==False: 
        caso=0
        while estado_perpendicular2: 
            caso+=1 
            radiante_caso=caso_radiantes(caso)    
            perpendicular_angle_radians = angulo_radiante_componente + radiante_caso   #SE SUMA EL ANGULO DEL COMPONENTE
            newX_rotado =  punto_cercano.x + distancia * np.cos(perpendicular_angle_radians) 
            newY_rotado =  punto_cercano.y + distancia * np.sin(perpendicular_angle_radians)    
            new_vertice= Point([newX_rotado,newY_rotado]) 

            angulo_grados = calcular_angulo_entre_punto_y_linea(new_vertice, linea)  
            if (angulo_grados >=80 and angulo_grados<=90) :   
                angulo_componente=perpendicular_angle_radians  
                estado_perpendicular2=False 
                perpendicular=True

            elif (angulo_grados<80 and caso>16) or (angulo_grados>90 and caso>16):
                estado_perpendicular2=False 
                perpendicular=False  

    #------TERCER CASO---
    if perpendicular==False: 
        caso=0 
        angulo_grados = calcular_angulo_entre_punto_y_linea(point, linea) 
        while estado_perpendicular3: 
            caso+=1 
            radiante_caso=caso_radiantes(caso)    
            perpendicular_angle_radians = np.radians(angulo_grados) + radiante_caso   #SE SUMA EL ANGULO DEL COMPONENTE
            newX_rotado =  punto_cercano.x + distancia * np.cos(perpendicular_angle_radians) 
            newY_rotado =  punto_cercano.y + distancia * np.sin(perpendicular_angle_radians)    
            new_vertice= Point([newX_rotado,newY_rotado]) 

            angulo_grados = calcular_angulo_entre_punto_y_linea(new_vertice, linea)  
            if (angulo_grados >=80 and angulo_grados<=90) :   
                angulo_componente=perpendicular_angle_radians  
                estado_perpendicular3=False 
                perpendicular=True 
            elif (angulo_grados<80 and caso>16) or (angulo_grados>90 and caso>16):
                estado_perpendicular3=False 
                perpendicular=False  
    #------CUARTO CASO---
    if perpendicular==False: 
        caso=0
        while estado_perpendicular4: 
            caso+=1 
            radiante_caso=caso_radiantes(caso)    
            perpendicular_angle_radians = angulo_radiante_componente - radiante_caso   #SE SUMA EL ANGULO DEL COMPONENTE
            newX_rotado =  punto_cercano.x + distancia * np.cos(perpendicular_angle_radians) 
            newY_rotado =  punto_cercano.y + distancia * np.sin(perpendicular_angle_radians)    
            new_vertice= Point([newX_rotado,newY_rotado]) 

            angulo_grados = calcular_angulo_entre_punto_y_linea(new_vertice, linea)  
            if (angulo_grados >=80 and angulo_grados<=90) :   
                angulo_componente=perpendicular_angle_radians  
                estado_perpendicular4=False 
                perpendicular=True

            elif (angulo_grados<80 and caso>16) or (angulo_grados>90 and caso>16):
                estado_perpendicular4=False 
                perpendicular=False   

    #------QUINTO CASO---
    if perpendicular==False: 
        caso=0 
        angulo_grados = calcular_angulo_entre_punto_y_linea(point, linea) 
        while estado_perpendicular4: 
            caso+=1 
            radiante_caso=caso_radiantes(caso)    
            perpendicular_angle_radians = np.radians(angulo_grados) + radiante_caso   #SE SUMA EL ANGULO DEL COMPONENTE
            newX_rotado =  punto_cercano.x + distancia * np.cos(perpendicular_angle_radians) 
            newY_rotado =  punto_cercano.y + distancia * np.sin(perpendicular_angle_radians)    
            new_vertice= Point([newX_rotado,newY_rotado]) 

            angulo_grados = calcular_angulo_entre_punto_y_linea(new_vertice, linea)  
            if (angulo_grados >=80 and angulo_grados<=90) :   
                angulo_componente=perpendicular_angle_radians  
                estado_perpendicular4=False 
                perpendicular=True 
            elif (angulo_grados<80 and caso>16) or (angulo_grados>90 and caso>16):
                estado_perpendicular4=False 
                perpendicular=False 
    
    return  angulo_componente


#------------  VALE, PERO CONFUNDE POSTES 
def move_point_perpendicular_to_lineBajante(punto_cercano, point,distancia,line,lado): 
    angle_radians=0 
    radiante_lado=0
    newX_rotado=[]
    newY_rotado=[]
    estado_perpendicular_A=False
    new_vertice=[]
    if lado=="DERECHA":  
        radiante_lado=2*np.pi
    elif lado=="IZQUIERDA":
        radiante_lado=np.pi
    elif lado == "ABAJO": 
        radiante_lado=3*(np.pi/2)
    elif lado =="ARRIBA":
        radiante_lado=(np.pi/2)
 
    #punto_cercano = line.interpolate(line.project(point)) 
    #punto_cercano=poste
    angle_radians = np.arctan2( point.y -punto_cercano.y, point.x  -punto_cercano.x) 
    angulo_grados= np.degrees(angle_radians)  
    perpendicular_angle_radians=0  
    #--ANGULOS POSITIVOS
    if angulo_grados >0 and angulo_grados < 90:
        diff_union = 90-angulo_grados 
        perpendicular_angle_radians = radiante_lado#angle_radians   + np.radians(diff_union) #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif angulo_grados> 90:
        diff_union = angulo_grados-90 
        perpendicular_angle_radians = angle_radians  + np.radians(diff_union) #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif (angulo_grados> 89 and angulo_grados<91) or (angulo_grados< -88 and angulo_grados > -91):
        perpendicular_angle_radians=angle_radians 
        estado_perpendicular_A=True 
    elif angulo_grados < -90 :
        diff_union = angulo_grados + 90
        #diff_union =angulo_grados -(diff_union) 
        perpendicular_angle_radians = angle_radians   -np.radians(diff_union)  #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif angulo_grados >-90  and angulo_grados <0:
        diff_union = 90 -angulo_grados
        perpendicular_angle_radians = angle_radians  + np.radians(-(diff_union))
    # VALIDAR SOLO ANGULOS DIFERENTES A 90 0 -90, Y APLICAR ROTACION
    if not estado_perpendicular_A:
        newX_rotado =  punto_cercano.x +distancia * np.cos(perpendicular_angle_radians) 
        newY_rotado =  punto_cercano.y +distancia* np.sin(perpendicular_angle_radians)
        new_vertice=[newX_rotado,newY_rotado]
  
    elif estado_perpendicular_A: 
       new_vertice=[point.x,point.y] 
    nuevo_angulo = np.arctan2( newY_rotado -punto_cercano.y, newX_rotado  -punto_cercano.x) 
    #print(angulo_grados,"-****---ANGULO CORREGIDO Y DESPLAZADO ES ----",np.degrees(nuevo_angulo))
    return  Point(new_vertice) 
    


def move_iluminaria_perpendicular_to_line(poste,line, point, distance,lado): 
    angle_radians=0 
    radiante_lado=0
    estado_perpendicular_A=False
    new_vertice=[]
    #-------------------- CASO CUANDO LA LINEA MTM TIENE SOLOS DOS VERTICES EN UNA SOLA DIRECCION
    # Obtener las coordenadas de los puntos finales de la línea
    x1, y1 = line.coords[0]
    x2, y2 = line.coords[-1] 
    # Calcular el ángulo actual entre la línea  en radianes
    angle_radians = np.arctan2(y2 - y1, x2 - x1)
    angulo_grados= math.degrees(angle_radians) 
    perpendicular_angle_radians=0 
    if angulo_grados < 90:
        # Ajustar el ángulo a 90 grados más o menos respecto al ángulo original
        perpendicular_angle_radians = angle_radians - (np.pi / 2)#SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif angulo_grados> 90:
        # Ajustar el ángulo a 90 grados más o menos respecto al ángulo original
        perpendicular_angle_radians = angle_radians + (np.pi / 2)#SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    # Calcular las coordenadas del punto perpendicular al punto original
    new_x = x1 + distance * np.cos(perpendicular_angle_radians)
    new_y = y1 + distance * np.sin(perpendicular_angle_radians) 
    new_vertice=[new_x,new_y]
    #-------CASO CORRECION DE VERTICE INTERPOLADO----    
    if  Point(new_vertice).distance(poste)>1.76:
        #SE VALIDA EL LADO DE LA LINEA PARA OBTENER RADIANTE PARA GIRAR SEGUN EL LADO DIFERENCIA
        if lado=="DERECHA":  
            radiante_lado=2*np.pi
        elif lado=="IZQUIERDA":
            radiante_lado=np.pi
        elif lado == "ABAJO": 
            radiante_lado=3*(np.pi/2)
        elif lado =="ARRIBA":
            radiante_lado=(np.pi/2) 
        #--- CASO 2 CORRECION POSTE NUEVO CERCANO EN DIFERECIA 
        punto_cercano =[]
        punto_cercano = line.interpolate(line.project(point)) 
        #---SE USA EL POSTE CERCANO SI NO EXISTE  VERTICE INTERPOLADO
        if punto_cercano.is_empty:#SE USA EL POSTE CERCANO
            punto_cercano=poste 
            angle_radians = np.arctan2( point.y -punto_cercano.y, point.x  -punto_cercano.x)#ANGULO ENTRE VERTICE Y POSTE CERCANO
        

        angulo_grados= np.degrees(angle_radians)  
        perpendicular_angle_radians=0 

        #--ANGULOS POSITIVOS-----
        #   menor a noventa
        if angulo_grados >0 and angulo_grados < 90 and lado=='ARRIBA':#------POSITIVO DERECHO
            diff_union = angulo_grados-90 
            perpendicular_angle_radians = angle_radians  - np.radians(diff_union)  #radiante_lado#SE ENCUNTRA EL NUEVO ANGULO EN RADIANES 
            #print("---------11 DERECHO-- ANGULO POSITIVO MAYOR 0 MENOR A 90 -->",angulo_grados,np.degrees(perpendicular_angle_radians))
        elif angulo_grados >0 and angulo_grados < 80 and lado=='DERECHA':#------POSITIVO DERECHO
            diff_union = angulo_grados-90 
            perpendicular_angle_radians = angle_radians  - np.radians(diff_union)  #radiante_lado#SE ENCUNTRA EL NUEVO ANGULO EN RADIANES 
            #print("---------11 DERECHO-- ANGULO POSITIVO MAYOR 0 MENOR A 90 -->",angulo_grados,np.degrees(perpendicular_angle_radians))
        
        elif angulo_grados >0 and angulo_grados < 80 and lado=='IZQUIERDA':#------POSITIVO IZQUIERDA
            diff_union = angulo_grados-90 
            perpendicular_angle_radians = angle_radians  - np.radians(diff_union)  #radiante_lado#SE ENCUNTRA EL NUEVO ANGULO EN RADIANES 
            #print("---------2222 DERECHO-- ANGULO POSITIVO MAYOR 0 Y MENOR A 90 -->",angulo_grados,np.degrees(perpendicular_angle_radians))
        
        elif angulo_grados >0 and angulo_grados> 90:#******* POSITIVO MAYOR A 0 Y 90
            diff_union = angulo_grados-90 
            perpendicular_angle_radians = radiante_lado#angle_radians  - np.radians(diff_union)  #radiante_lado#SE ENCUNTRA EL NUEVO ANGULO EN RADIANES 
            #print("---------333-- ANGULO POSITIVO MAYOR 0 Y A 90 -->",angulo_grados,np.degrees(perpendicular_angle_radians))
        
        #********** angulos rectos antiguos, ya sea positivo o negativo
        elif  (angulo_grados> 80 and angulo_grados<91  ) or (angulo_grados< -88 and angulo_grados > -91):
            perpendicular_angle_radians=angle_radians 
            estado_perpendicular_A=True 
            #print("---------4444-- ANGULO ANTIGUO ESTA APROXIMADO A 90 -->",angulo_grados,np.degrees(perpendicular_angle_radians))
        
        #------------------------------NEGATIVOS-------------------
        elif angulo_grados < -101  and angulo_grados <0 and lado=='DERECHA':
            diff_union = angulo_grados + 90
            #diff_union =angulo_grados -(diff_union) 
            perpendicular_angle_radians = angle_radians   - np.radians(diff_union)  #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
            #print("---------5555--- ANGULO NEGATIVO MENOR -90 Y MENOR A 0 -->",angulo_grados,np.degrees(perpendicular_angle_radians))

        elif angulo_grados >-90  and angulo_grados <0 and lado=='DERECHA': 
            diff_union = 90 -angulo_grados
            perpendicular_angle_radians =-( angle_radians  - np.radians(-diff_union) )
            #print("---------6666-- ANGULO ANTIGUO ESTA APROXIMADO A 90 -->",angulo_grados,np.degrees(perpendicular_angle_radians))
         

        elif angulo_grados >-90  and angulo_grados <0 and lado=='IZQUIERDA':  
            diff_union = 90 +angulo_grados
            perpendicular_angle_radians =  angle_radians  +np.radians(-(diff_union)) 
            #print(np.degrees(perpendicular_angle_radians),"----7777---Valor de diferencia cuando el angulo es < 0 y mayor a -90 --->",diff_union,angulo_grados)
            


        elif angulo_grados >-90  and angulo_grados <0 and lado=='ABAJO':
            diff_union = 90 -angulo_grados
            perpendicular_angle_radians =-(angle_radians - np.radians(-diff_union) )
            #print("---------8888--- ANGULO NEGATIVO MAYOR A -90 Y MENOR A 0->",angulo_grados,np.degrees(perpendicular_angle_radians))
        # ------VALIDAR SOLO ANGULOS DIFERENTES A 90 0 -90, Y APLICAR ROTACION

        if not estado_perpendicular_A:
            newX_rotado =  punto_cercano.x +distance * np.cos(perpendicular_angle_radians) 
            newY_rotado =  punto_cercano.y +distance* np.sin(perpendicular_angle_radians)
            new_vertice=[newX_rotado,newY_rotado]
        elif estado_perpendicular_A: 
            newX_rotado =  point.x,point.x
            newY_rotado = point.x,point.y 
            new_vertice=[point.x,point.y]  
        nuevo_angulo = np.arctan2( newY_rotado -punto_cercano.y, newX_rotado  -punto_cercano.x) 
        #print(lado,">>",angulo_grados,"<<---***********---ANGULO CORREGIDO Y DESPLAZADO ES ---->>>>>",np.degrees(nuevo_angulo))
    else:
        nuevo_angulo = np.arctan2( new_vertice[0] -x1, new_vertice[1]  -y1) 
        #print(lado,">>",angulo_grados,"<<---***********--angulo Y DESPLAZADO ES ---->>>>>",np.degrees(nuevo_angulo))
    
    return  Point(new_vertice)

def calcular_angulo_entre_lineas(vector1, vector2):
    # Calcular el producto punto de los dos vectores
    producto_punto = np.dot(vector1, vector2) 
    # Calcular las magnitudes de los vectores
    magnitud_vector1 = np.linalg.norm(vector1)
    magnitud_vector2 = np.linalg.norm(vector2) 
    # Calcular el coseno del ángulo entre los vectores
    coseno_angulo = producto_punto / (magnitud_vector1 * magnitud_vector2) 
    # Calcular el ángulo en radianes
    angulo_radianes = np.arccos(np.clip(coseno_angulo, -1.0, 1.0))
    
    # Convertir el ángulo a grados
    angulo_grados = np.degrees(angulo_radianes)
    
    return angulo_grados

 

def mover_angulo_punto_con_dos_lineas(poste,punto,distancia, linea1, linea2):
    # Verificar que las entradas sean instancias de Point y LineString 
    # Encontrar el punto de intersección entre las dos líneas
    #punto_interseccion = linea1.intersection(linea2)
    punto_interseccion = poste 
 
    # Calcular el ángulo entre la línea 1 y el punto de intersección
    angle1 = np.arctan2(punto.y - punto_interseccion.y, punto.x - punto_interseccion.x)

    # Calcular el ángulo entre la línea 2 y el punto de intersección
    #angle2 = np.arctan2(punto.y - punto_interseccion.y, punto.x - punto_interseccion.x)

    # Calcular el ángulo promedio
    average_angle = (angle1) / 2

    # Ajustar el ángulo a 90 grados
    perpendicular_angle = average_angle + (np.pi / 2)
    # Calcular las nuevas coordenadas del punto movido perpendicularmente
    new_x = punto_interseccion.x + distancia * np.cos(perpendicular_angle)
    new_y = punto_interseccion.y + distancia * np.sin(perpendicular_angle)
    # Crear el nuevo punto movido perpendicularmente
    punto_movido = Point(new_x, new_y)
    return punto_movido 

# Se filtra lineas con vertices cercnos
def filtar_linea_vertices(linea,cantidad,componente): 
    linea = gpd.GeoSeries([linea]) 
    distances = linea.apply(lambda geom: componente.distance(geom)) 

    #Se encuentra  el index del vertice con distancia minima al punto
    min_distance_index = distances.idxmin()   
    new_lineaMTM=[]
    if cantidad==2:#-------Linea con dos vertices o coordenadas 
        if min_distance_index == 0:#Posicion vertice INICIO interpolado en 
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index])  
            new_lineaMTM.append(linea.iloc[0].coords[-1])  

    elif cantidad>2: #-------- numero de vertices mayor a 2 coordenadas en lineas
        if min_distance_index == 0:#Posicion inicio vertice interpolado  
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index])
            new_lineaMTM.append(linea.iloc[0].coords[min_distance_index+1])  
      
    #---VERTICE COORDENADA CERCANA DISTANCIA MINIMA EN LA LINEA
    #-----NO SE APLICA REGISTRO DE POSTES
    new_lineaMTM = LineString(new_lineaMTM) 
    punto_cercano = Point(new_lineaMTM.coords[:][min_distance_index])  
    return new_lineaMTM, punto_cercano



#----------------INICIO 
                              
def move_point_perpendicular_to_line(poste,linea, point, distance,lado,posicion_linea): 
    radiante_lado=0
    estado_perpendicular_A=False 
    perpendicular_angle_radians=0 
    new_vertice=[]
    newX_rotado=[] 
    newY_rotado=[]
    cantidad_vertices = len(linea.coords[:])   
    linea_vertices_cercanos,punto_cercano= filtar_linea_vertices(linea,cantidad_vertices,point) 


    linea=linea_vertices_cercanos

    angle_radians =  np.radians(calcular_angulo_entre_punto_y_linea(point, linea)) 
    angulo_grados = np.degrees(angle_radians)   
    angulo_radiante_componente= angle_seccionador_poste(poste,point)   
    #--ANGULO PUNTO Y LINEA POSITIVOS----- 
    if angulo_grados >0 and angulo_grados < 90 :#------POSITIVO DERECHO

        diff_union = 90 - angulo_grados 
        perpendicular_angle_radians = np.radians(angulo_radiante_componente)  + np.radians(diff_union)     
        newX_rotado =  poste.x +distance * np.cos(perpendicular_angle_radians) 
        newY_rotado =  poste.y +distance * np.sin(perpendicular_angle_radians) 
        new_vertice= Point([newX_rotado,newY_rotado])   
        angulo_grados = calcular_angulo_entre_punto_y_linea(new_vertice, linea) 

        if angulo_grados <80 or angulo_grados>90 or  linea.distance(new_vertice)<0.34: 

            orientacion_vertice_diferencia, posicion_linea =  get_line_point_relative_position_correcion(point, linea,poste) 
            perpendicular_angle_radians = move_point_perpendicular_to_lineBajante_componente(poste, point,distance,linea,orientacion_vertice_diferencia,posicion_linea) 
     
    elif angulo_grados > 90 :

        diff_union = angulo_grados-90   
        perpendicular_angle_radians = np.radians(angulo_radiante_componente)  - np.radians(diff_union)   
        
        newX_rotado =  punto_cercano.x + distance * np.cos(perpendicular_angle_radians) 
        newY_rotado =  punto_cercano.y + distance * np.sin(perpendicular_angle_radians)    
        new_vertice= Point([newX_rotado,newY_rotado])   
        angulo_grados = calcular_angulo_entre_punto_y_linea(new_vertice, linea)  

        if angulo_grados <80 or angulo_grados>90 or  linea.distance(new_vertice)<0.34: 
            orientacion_vertice_diferencia, posicion_linea =  get_line_point_relative_position_correcion(point, linea,poste) 
            perpendicular_angle_radians = move_point_perpendicular_to_lineBajante_componente(poste, point,distance,linea,orientacion_vertice_diferencia,posicion_linea) 
    
    
    #----------------APLICAR GIRO PERPENDICULAR     
    newX_rotado =  poste.x +distance * np.cos(perpendicular_angle_radians) 
    newY_rotado =  poste.y +distance * np.sin(perpendicular_angle_radians) 
    new_vertice= [newX_rotado,newY_rotado]  
    return  Point(new_vertice)
 
def calcular_angulo_entre_punto_y_linea(punto, linea): 
    vector_punto_a_linea = np.array([linea.coords[0][0] - punto.x , linea.coords[0][1] - punto.y]) 
    vector_linea = np.array([linea.coords[0][0] - linea.coords[1][0], linea.coords[0][1] - linea.coords[1][1]])
    
    angulo_entre_punto_y_linea = calcular_angulo_entre_lineas(vector_punto_a_linea, vector_linea) 
    return angulo_entre_punto_y_linea

def find_angle_between_lines(line1, line2):  
    intersection_coords = line1.coords[0] #intersection_point.geometry[0].coords[0]

    # Calcular el ángulo entre las líneas usando np.arctan2
    angle_radians = np.arctan2(line2.coords[1][1] - intersection_coords[1],
                                line2.coords[1][0] - intersection_coords[0]) - \
                    np.arctan2(line1.coords[1][1] - intersection_coords[1],
                                line1.coords[1][0] - intersection_coords[0])

    # Convertir el ángulo a grados
    angle_degrees = np.degrees(angle_radians)

    return angle_degrees 
# SE PRESENTA LA FUNCION DE CORRECION DE COMPONENTES
def correcion_componentes_electronicos(poste,line, point, distance,lado,linea_posicion): 
    angle_radians=0 
    radiante_lado=0
    estado_perpendicular_A=False
    new_vertice=[]
    if lado=="DERECHA":  
        radiante_lado=2*np.pi
    elif lado=="IZQUIERDA":
        radiante_lado=np.pi
    elif lado == "ABAJO": 
        radiante_lado=3*(np.pi/2)
    elif lado =="ARRIBA":
        radiante_lado=(np.pi/2)
 
    punto_cercano = line.interpolate(line.project(point)) 
    if not punto_cercano or punto_cercano.distance(poste) >1.50:
       punto_cercano=poste
    angle_radians = np.arctan2( point.y -punto_cercano.y, point.x  -punto_cercano.x) 

    angulo_grados= np.degrees(angle_radians)  
    perpendicular_angle_radians=0  
    #--ANGULOS POSITIVOS
    if angulo_grados >0 and angulo_grados < 90:
        diff_union = 90-angulo_grados 
        perpendicular_angle_radians = radiante_lado# np.radians(diff_union) #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif angulo_grados> 90:
        diff_union = angulo_grados-90 
        perpendicular_angle_radians = angle_radians  + np.radians(diff_union) #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif (angulo_grados> 89 and angulo_grados<91) or (angulo_grados< -88 and angulo_grados > -91):
        perpendicular_angle_radians=angle_radians 
        estado_perpendicular_A=True 
    elif angulo_grados < -90 :
        diff_union = angulo_grados + 90
        #diff_union =angulo_grados -(diff_union) 
        perpendicular_angle_radians = angle_radians   -np.radians(diff_union)  #SE ENCUNTRA EL NUEVO ANGULO EN RADIANES
    elif angulo_grados >-90  and angulo_grados <0:
        diff_union = 90 -angulo_grados
        perpendicular_angle_radians = angle_radians  + np.radians(-(diff_union))
    # VALIDAR SOLO ANGULOS DIFERENTES A 90 0 -90, Y APLICAR ROTACION
    if not estado_perpendicular_A:
        newX_rotado =  punto_cercano.x +distance * np.cos(perpendicular_angle_radians) 
        newY_rotado =  punto_cercano.y +distance* np.sin(perpendicular_angle_radians)
        new_vertice=[newX_rotado,newY_rotado]
        
  
    elif estado_perpendicular_A: 
       new_vertice=[point.x,point.y] 
    nuevo_angulo = np.arctan2( newY_rotado -punto_cercano.y, newX_rotado  -punto_cercano.x) 
    print(angulo_grados,linea_posicion,"-****---ANGULO COMPONENTE --CORREGIDO Y DESPLAZADO ES ----",np.degrees(nuevo_angulo))
    return  Point(new_vertice) 
    

# Función para combinar geometrías de postes antiguos y nuevos
def obtener_geometrias_combinadas(shapefile_antiguos, shapefile_nuevos):
    # Cargar los archivos shapefile de postes antiguos y nuevos
    shp_postesAntiguos = gpd.read_file(shapefile_antiguos)
    shp_postesNuevos = gpd.read_file(shapefile_nuevos)
    res = []
    try:
        for codigo1,codigoelem, nuevo in zip(shp_postesNuevos['OBJECTID_1'],shp_postesNuevos['OBJECTID'], shp_postesNuevos['geometry']):
            # SE APLICA ESTXTRACION DE COORDENADAS EN X Y MENOS LA Z 
            for id_antiguo, antiguo in zip(shp_postesAntiguos['OBJECTID'], shp_postesAntiguos['geometry']):
                if codigoelem and int(codigoelem) == id_antiguo:
                    geometria_combinada = {
                        'OBJECTID': codigo1,
                        'id_antiguo': id_antiguo,
                        'id_nuevo': codigo1,
                        'coordenadas_antiguas': antiguo.coords[:],
                        'coordenadas_nuevas': [nuevo.coords[0][0:2]],
                    }
                    res.append(geometria_combinada)
    except:
        try:
            for _, codigoelem, nuevo in zip(shp_postesNuevos['OBJECTID'], shp_postesNuevos['CODIGOELEM'], shp_postesNuevos['geometry']):
                for id_antiguo, antiguo in zip(shp_postesAntiguos['OBJECTID'], shp_postesAntiguos['geometry']):
                    if codigoelem and int(codigoelem) == id_antiguo:
                        geometria_combinada = {
                            'OBJECTID': _,
                            'id_antiguo': id_antiguo,
                            'id_nuevo': _,
                            'coordenadas_antiguas': antiguo.coords[:],
                            'coordenadas_nuevas': nuevo.coords[:],
                        }
                        res.append(geometria_combinada)
        except:
            for codigo1, nuevo in zip(shp_postesNuevos['OBJECTID'], shp_postesNuevos['geometry']):
                # SE APLICA ESTXTRACION DE COORDENADAS EN X Y MENOS LA Z 
                for id_antiguo, antiguo in zip(shp_postesAntiguos['OBJECTID'], shp_postesAntiguos['geometry']):
                    if codigo1 and int(codigo1) == id_antiguo:
                        geometria_combinada = {
                            'OBJECTID': codigo1,
                            'id_antiguo': id_antiguo,
                            'id_nuevo': codigo1,
                            'coordenadas_antiguas': antiguo.coords[:],
                            'coordenadas_nuevas': [nuevo.coords[0][0:2]],
                        }
                        res.append(geometria_combinada)

    return res 


#-----------------------FIN-------------------------------------
#FUNCION PARA DIVIDIR 1 LINEA MEDIANTE una distancia dada de 1M
def funcion_corte_linea(linea_cortar,seccionador,distancia): 
    buffer_coordI = Point(linea_cortar.coords[0]).buffer(1.5)# buffer de un metro en el vertice recorrido
    buffer_coordF = Point(linea_cortar.coords[-1]).buffer(1.5)# buffer de un metro en el vertice recorrido
    punto_corte= [] 
    seccionador_movido=[]
    segment1=[]
    segment2=[]
    if Point(seccionador[0]).within(buffer_coordI): 
        punto_corte= linea_cortar.interpolate(-distancia)  
        seccionador_movido=Point(punto_corte.x,punto_corte.y)
        segment1 = LineString([linea_cortar.coords[0],(punto_corte.x,punto_corte.y)])
        segment2 = LineString([(punto_corte.x,punto_corte.y),linea_cortar.coords[-1]])  
    if Point(seccionador[0]).within(buffer_coordF):  
        punto_corte= linea_cortar.interpolate(distancia) 
        seccionador_movido=Point(punto_corte.x,punto_corte.y)
        segment1 = LineString([linea_cortar.coords[-1],(punto_corte.x,punto_corte.y)])
        segment2 = LineString([(punto_corte.x,punto_corte.y),linea_cortar.coords[0]])     
    return segment1, segment2, seccionador_movido

def rotar_punto_alrededor_de_linea(punto, linea, angulo_grados):
    # Crear un punto Shapely a partir de la tupla de coordenadas
    punto_shapely = Point(punto)
    # Obtener el punto de referencia para la rotación (un punto en la línea)
    punto_referencia = linea.interpolate(0.5, normalized=True)
    # Rotar el punto alrededor del punto de referencia
    punto_rotado = punto_shapely.rotate(angulo_grados, origin=punto_referencia)
    return punto_rotado
def posicion_punto_con_respecto_a_linea(punto, linea, vertice_cercano):
    # Convierte las coordenadas de entrada a objetos Shapely
    punto_shapely = Point(punto)
    linea_shapely = LineString(linea)
    vertice_cercano_shapely = Point(vertice_cercano)

    # Calcula la distancia del punto al vértice cercano
    distancia_punto_a_vertice = punto_shapely.distance(vertice_cercano_shapely)

    # Proyecta el punto sobre la línea y calcula la distancia a la proyección
    proyeccion_punto = linea_shapely.interpolate(linea_shapely.project(punto_shapely))
    distancia_punto_a_proyeccion = punto_shapely.distance(proyeccion_punto)

    # Determina la posición relativa del punto con respecto a la línea
    if distancia_punto_a_proyeccion < distancia_punto_a_vertice:
        return "Izquierda"
    elif distancia_punto_a_proyeccion > distancia_punto_a_vertice:
        return "Derecha"
    else:
        return "Sobre la línea"  
 
# Función para actualizar las coordenadas de una línea DE ALTA TENSION
def actualizar(linea_antigua, coordenada_antigua, coordenada_nueva, precision=4):
    nueva_linea_coords = [] 
    
    for coord in linea_antigua.coords:
        #print(round_coordinates(coordenada_antigua[0], precision),"...valor....",round_coordinates(coord, precision))
        rounded_old_coord = round_coordinates(coord, precision)
        #VALIDAR SI, NO EXISTE PO
        rounded_new_coord = round_coordinates(coordenada_antigua[0], precision)
        
        punto1 = Point(rounded_old_coord)
        punto2 = Point(rounded_new_coord)
        
        distt = punto1.distance(punto2)
        
        if distt < 2:
            nueva_linea_coords.append(coordenada_nueva[0])
        else:
            nueva_linea_coords.append(coord) 
    return nueva_linea_coords


 

#FUNCION PARA ACTUALIZAR SECCIONADORESA POSTES VIEJOS Y NUEVOS y linea cercana
def funcion_actualizar_seccionadores_postes(shapefile_postesA,shapefile_postesM,shapefile_seccionadoresA,shapefile_lineasMTM):
    capa_seccionadores_A = gpd.read_file(shapefile_seccionadoresA)
    capa_lineasMTM = gpd.read_file(shapefile_lineasMTM)
    combinaciones_postesAM = obtener_geometrias_combinadas(shapefile_postesA,shapefile_postesM)

    for indexSec, seccionador in capa_seccionadores_A.iterrows(): 
        buffer_seccionador_a = seccionador['geometry'].buffer(2)# A 1 METRO DE POSTE ANTIGUO
        for combinado in combinaciones_postesAM:
            if Point(combinado['coordenadas_antiguas'][0]).within(buffer_seccionador_a): 
                lineamtm_cercana=[] 
                distancia_corte=1.0
                #SE OBTIENE LA DIFERENCIA O DISTANCIA ENTRE SECIONADOR Y POSTE ANTERIOR
                diff_xS=  combinado['coordenadas_antiguas'][0][0] - seccionador.geometry.coords[0][0]
                diff_yS=  combinado['coordenadas_antiguas'][0][1] - seccionador.geometry.coords[0][1]
                seccionar_diff =Point(combinado['coordenadas_nuevas'][0][0] -diff_xS,combinado['coordenadas_nuevas'][0][1]+diff_yS)
                #BUSCAR LINEA CERCANA AL SECCIONADOR PARA CORTAR LA LINEA EN DISTANCIA DEL SECCIONADOR
                for indexLm, lineaMTM in capa_lineasMTM.iterrows():
                    
                     

                    if  lineaMTM.geometry.distance(seccionar_diff)<1.5:
                        lineamtm_cercana=lineaMTM['geometry'] 
                        #REALIZANDO PUNTOS DE CORTE EN LINEA CERCANA A NUEVO VERTICE
                        segmento1,segmento2,seccionador_movido = funcion_corte_linea(lineamtm_cercana,seccionador.geometry.coords[:],distancia_corte) 
                        if segmento1 and segmento2 and seccionador_movido:
                            capa_lineasMTM.at[indexLm,'geometry'] = segmento1  
                            capa_seccionadores_A.at[indexSec,'geometry']= seccionador_movido#Point(combinado['coordenadas_nuevas'][0][0] -diff_xS,combinado['coordenadas_nuevas'][0][1]+diff_yS)
                            new_gdf = gpd.GeoDataFrame(geometry=[segmento2])
                            capa_lineasMTM.at[indexLm,'geometry']= LineString(segmento1)  
                            # Concatena el nuevo GeoDataFrame con el GeoDataFrame existente
                            #capa_lineasMTM = gpd.concat([capa_lineasMTM, new_gdf], ignore_index=True)
                        #break 
    capa_seccionadores_A.to_file("./movido/SECCIONADORES_MOVIDAS.shp")  
    

#FUNCION PARA MOVER PROTECCIONES MEDIATE DIFIERENCIA DE VERTICE transformador
def funcion_girar_componentes_caso_objectid(shapefile_seccionadoresF_M,shapefile_transformador_M,shapefile_protector_M,shapefile_uniones_M,shapefile_poste_M): 
    capa_seccionadoresF_movidas = gpd.read_file(shapefile_seccionadoresF_M)
    capa_postes_movidos = gpd.read_file(shapefile_poste_M)
    capa_protectores_movidas = gpd.read_file(shapefile_protector_M)   
    capa_transformadores_movidas=gpd.read_file(shapefile_transformador_M)   
    capa_unionesBT_movidas=gpd.read_file(shapefile_uniones_M)    
    #PREGUNTA QUE VERTICE ESTA CERCA AL SECCIONADOR PARA OBTENER EL VERTICE EXTREMO AL POSTE 
    #----caso=1 derecha  caso 2 iquierda ,, caso 3 arriba, caso 4 abajo
    codigo_caso=[] 
    codigo_caso.append((9,2))
    codigo_caso.append((17,4))
    codigo_caso.append((19,1)) 
    codigo_caso.append((26,2))
    codigo_caso.append((30,3))
    codigo_caso.append((39,3))
    codigo_caso.append((72,4)) 
    for objectid_caso in codigo_caso:
        for indexTA, transformador in capa_transformadores_movidas.iterrows(): 
            if transformador['OBJECTID']==objectid_caso[0]: 
                #SE OBTIENE TRANSFORMADOR POR CODIGO PUESTO PARA VALIDAR PROPIEDADES Y SUBTIPO CONECTADOS A POSTE 
                transformador_perpendicular=transformador
                seccionador_perpendicular =  capa_seccionadoresF_movidas[capa_seccionadoresF_movidas['CODIGOPUES'] == transformador['CODIGOPUES']]  
                buffer_seccionador = seccionador_perpendicular.iloc[0].geometry.buffer(0.40)        
                poste_movido = capa_postes_movidos[capa_postes_movidos.geometry.within(buffer_seccionador)]       

                protector_seccionador = capa_protectores_movidas[capa_protectores_movidas['CODIGOPUES'] == transformador['CODIGOPUES']]   
                
                buffer_protector=protector_seccionador.iloc[0].geometry.buffer(0.40)
                union_protector =capa_unionesBT_movidas[capa_unionesBT_movidas.geometry.within(buffer_protector)]  
                print("-----objest id de transofrmador es >>",transformador['OBJECTID']) 
                print("-----objest id de seccionador es >>",seccionador_perpendicular['OBJECTID'])    
                print("-----objest id de poste es >>",poste_movido['OBJECTID'])   
                print("-----objest id de UNION EN PROTECTORes >>",union_protector['OBJECTID'])  


                seccionador_new = girar_componente_caso(seccionador_perpendicular.geometry,objectid_caso[1],poste_movido.iloc[0].geometry) 
                transformador_new =  girar_componente_caso(transformador_perpendicular.geometry,objectid_caso[1],poste_movido.iloc[0].geometry) 
                protector_new = girar_componente_caso(protector_seccionador.geometry,objectid_caso[1],poste_movido.iloc[0].geometry) 
                union_new = girar_componente_caso(union_protector.geometry,objectid_caso[1],poste_movido.iloc[0].geometry) 

                capa_transformadores_movidas.at[indexTA,'geometry']=transformador_new  
                for indexSF, seccionador in seccionador_perpendicular.iterrows():
                    capa_seccionadoresF_movidas.at[indexSF,'geometry'] =seccionador_new
                for indexPro, protector in protector_seccionador.iterrows(): 
                    capa_protectores_movidas.at[indexPro,'geometry'] = protector_new  
                for indexUni, union in union_protector.iterrows():
                    capa_unionesBT_movidas.at[indexUni,'geometry'] = union_new
                break
                    
    capa_protectores_movidas.to_file("./movido/PROTECTORES_MOVIDO.shp") 
    capa_transformadores_movidas.to_file("./movido/TRANSFORMADORES_MOVIDO.shp") 
    capa_seccionadoresF_movidas.to_file("./movido/SECCIONADORES_F_MOVIDO.shp")  
    capa_unionesBT_movidas.to_file("./movido/UNIONES_MOVIDO.shp")      



#FUNCION PARA MOVER PROTECCIONES MEDIATE DIFIERENCIA DE VERTICE transformador
def funcion_actualizar_seccionadorTransformadorF_postesA(shapefile_seccionadoresF_A,shapefile_transformador_A,shapefile_protector_A,shapefile_poste_A,shapefile_poste_M,shapefile_lineasMTA,shapefile_lineasMTM,shapefile_lineasBTA,shapefile_unionesA,shapefile_iluminariaA): 
    capa_seccionadoresF_antiguos = gpd.read_file(shapefile_seccionadoresF_A)
    capa_protectores_antiguos = gpd.read_file(shapefile_protector_A)
    capa_lineasMT_movias= gpd.read_file(shapefile_lineasMTM)
    capa_lineasMT_antiguas= gpd.read_file(shapefile_lineasMTA)
    capa_lineasBT_antiguas=gpd.read_file(shapefile_lineasBTA)
    capa_unionesBT_antiguas=gpd.read_file(shapefile_unionesA)  
    capa_iluminarias_antiguas=gpd.read_file(shapefile_iluminariaA)  
    postes_combinados = obtener_geometrias_combinadas(shapefile_poste_A,shapefile_poste_M)
    capa_transformadores_antiguas=gpd.read_file(shapefile_transformador_A) 
    #PREGUNTA QUE VERTICE ESTA CERCA AL SECCIONADOR PARA OBTENER EL VERTICE EXTREMO AL POSTE
    distanciaR_seccionador=0.35
    distanciaR_transformador=0.70
    distanciaR_protector=1.05
    distanciaR_iluminaria=1.75
    distanciaR_Union=1.40 
    estado_falso=False

    global  total_componentes_poste
    global total_movidos
    global total_faltantes
    global lista_componentes_postes
    global lista_componentes_faltantes
    global lista_componentes_movidos
    #-----SECCIONADOR----
    for indexSF, seccionadorF in capa_seccionadoresF_antiguos.iterrows():
        estado_iluminaria=False
        correcion_componentes=False 
        #SE OBTIENE TRANSFORMADOR POR CODIGO PUESTO PARA VALIDAR PROPIEDADES Y SUBTIPO CONECTADOS A POSTE
        #-----------------TRANSFORMADOR----
        transformador_puestoUnico=capa_transformadores_antiguas[capa_transformadores_antiguas['CODIGOPUES']== seccionadorF['CODIGOPUES']]
        #-----------------PROTECTOR------
        protector_seccionador = capa_protectores_antiguos[capa_protectores_antiguos['CODIGOPUES'] == seccionadorF['CODIGOPUES']]     
        if not transformador_puestoUnico.empty and not protector_seccionador.empty:
            for indexTA,transformador_A in transformador_puestoUnico.iterrows(): 
                if transformador_A['PROPIEDAD'] in ['PARTICULAR','EEQ'] and transformador_A['SUBTIPO'] in [1,5,9,11,13]:#SOLO CONEXION A POSTE TRAMO AEREO    
                    #-------POSTES---COMBINADOS--- 
                    total_componentes_poste+=1
                    lista_componentes_postes.append(transformador_A['OBJECTID'])
                    estado_poste=False
                    for poste_combinado in postes_combinados:  
                        buffer_seccionadorA=seccionadorF.geometry.buffer(0.50) #1M
                        buffer_posteA=Point(poste_combinado['coordenadas_antiguas']).buffer(1) #1M
                        #---LINEA MEDIA TENSEION ANTIGUA BAJANTE CONEXION POSTE Y SECCIONADOR
                        lineas_bajantesCercanas = capa_lineasMT_antiguas[(capa_lineasMT_antiguas.intersects(buffer_seccionadorA)) & (capa_lineasMT_antiguas.intersects(buffer_posteA)) & (capa_lineasMT_antiguas['SUBTIPO'].isin([4,5,6]))]#RECUPERAR LINEAS EN VERTICE SECCIONADOR 
                        if not lineas_bajantesCercanas.empty:   
                            estado_poste=True
                            diffX= seccionadorF['geometry'].coords[0][0] - poste_combinado['coordenadas_antiguas'][0][0] 
                            diffY= seccionadorF['geometry'].coords[0][1] - poste_combinado['coordenadas_antiguas'][0][1]   
                            #DIFERENCIA SECCIONADOR ANTIGUO------
                            seccionador_diferencia=[(poste_combinado['coordenadas_nuevas'][0][0]+diffX,poste_combinado['coordenadas_nuevas'][0][1]+diffY)] 
                            # 2 LINEAS BAJATENSION ANTIGUA TIPO BAJANTE CONECTADO A PROTECTOR CODIGO PUESTO
                            lineaBTA_bajante=  capa_lineasBT_antiguas[(capa_lineasBT_antiguas.intersects(protector_seccionador.iloc[0].geometry.buffer(0.50))) & (capa_lineasBT_antiguas['SUBTIPO'].isin([4,5,6]))] 
                            #------UNION ANTIGUO-----
                            union_A=[]
                            for indexLBA, bajanteprotector in lineaBTA_bajante.iterrows():# 2 lineas bajantes--
                                union_A = capa_unionesBT_antiguas[(capa_unionesBT_antiguas.within(bajanteprotector.geometry.buffer(0.20)))]
                                if not union_A.empty:  
                                    break   
                            #-----ILUMINARIA ANTIGUA EN UNION A 0.40 M
                            iluminaria_A= capa_iluminarias_antiguas[capa_iluminarias_antiguas.intersects(union_A.iloc[0].geometry.buffer(0.40))] 
                            if not iluminaria_A.empty: #VALIDANDO SI EXISTE ILUMINAR EN EL CONJUNTO DE COMPONENTES ELECTRONICOS RECORRIDO
                                estado_iluminaria=True 
                            #--------LINEAS MEDIA TENSION MOVIDO, CERCANA AL COMPONENTE DIFERENCIA, TOMANDO COMO BASE EL SECCIONADOR DIFERENCIA------- 
                            lineaMTM_cercanas = capa_lineasMT_movias[(capa_lineasMT_movias.intersects(Point(poste_combinado['coordenadas_nuevas'][0]).buffer(1))) &  (capa_lineasMT_movias['SUBTIPO'].isin([1,2,3]))]# TIPO TRAMOS MEDIA TENSION ANTGIGUA
                             
                            if not lineaMTM_cercanas.empty:
                                lineamtm_perpendicular =[]  
                                if len(lineaMTM_cercanas)>=2: 
                                    lineamtm_perpendicular = encontrar_linea_mas_cercana(lineaMTM_cercanas,Point(seccionador_diferencia)) 
                                elif len(lineaMTM_cercanas)==1:
                                    lineamtm_perpendicular = lineaMTM_cercanas.iloc[0].geometry   

                                orientacion_vertice_diferencia, posicion_linea =  get_line_point_relative_position_correcion(Point(seccionador_diferencia), lineamtm_perpendicular,Point(poste_combinado['coordenadas_nuevas'][0])) #ORIENTACION BASE PARA TODOS LOS COMPONENTES CONECTADOS EN BAJANTES MTM 
                                seccionador_perpendicular =  move_point_perpendicular_to_line(Point(poste_combinado['coordenadas_nuevas'][0]),lineamtm_perpendicular, Point(seccionador_diferencia),distanciaR_seccionador,orientacion_vertice_diferencia,posicion_linea)                                        
                                #-error de detectado, aplicar filtro de linea entre vertices cuando es mayor a 2 puntos extremos
                                
                                cantidad_vertices = len(lineamtm_perpendicular.coords[:])  
                                linea_vertices_extremos,vertice_cercano = filtar_linea_vertices(lineamtm_perpendicular,cantidad_vertices,Point(seccionador_diferencia)) 
                                #old_angulo_punto_linea= calcular_angulo_entre_punto_y_linea(Point(seccionador_diferencia),linea_vertices_extremos)
                                #new_angulo_punto_linea= calcular_angulo_entre_punto_y_linea(seccionador_perpendicular,linea_vertices_extremos)
                                lado_antiguo,posicionlinea1 = get_line_point_relative_position_correcion(Point(seccionador_diferencia), linea_vertices_extremos, Point(poste_combinado['coordenadas_nuevas'][0]))
                                lado_nuevo,posicionlinea2 = get_line_point_relative_position_correcion(seccionador_perpendicular, linea_vertices_extremos, Point(poste_combinado['coordenadas_nuevas'][0]))
                                


                                #print(lado_antiguo,lado_nuevo,"---- CODIGO DE TRANSFORMADOR->>",transformador_A['OBJECTID'])
                                #print(f"Angulos automatizacion-->  Angulo antiguo: {old_angulo_punto_linea}, Angulo nuevo: {new_angulo_punto_linea}") 

                                angulo_seccionador=angle_seccionador_poste(Point(poste_combinado['coordenadas_nuevas'][0]),seccionador_perpendicular)
                                
                                if lado_antiguo!=lado_nuevo:  
                                    angulo_seccionador = (angulo_seccionador + 180) % 360  
                                else:
                                    angulo_seccionador= angulo_seccionador 

                                #---- SE VALIDA SI EL COMPONENTE SECCIONADOR ESTA CERCA  
                                if lineamtm_perpendicular.distance(seccionador_perpendicular) <0.34: #if not lineaMTM.empty:   
                                    total_faltantes+=1
                                    lista_componentes_faltantes.append(transformador_A['OBJECTID'])             
                                else:
                                    total_movidos+=1
                                    lista_componentes_movidos.append(transformador_A['OBJECTID'])
        
                                 
                                seccionador_perpendicular = girar_componente_angulo_seccionador(Point(poste_combinado['coordenadas_nuevas'][0]), Point(seccionador_diferencia),distanciaR_seccionador,angulo_seccionador)
                                protector_perpendicular = girar_componente_angulo_seccionador(Point(poste_combinado['coordenadas_nuevas'][0]), protector_seccionador.iloc[0].geometry,distanciaR_protector,angulo_seccionador)
                                transformador_perpendicular = girar_componente_angulo_seccionador(Point(poste_combinado['coordenadas_nuevas'][0]), transformador_A.geometry,distanciaR_transformador,angulo_seccionador)
                                union_perpendicular = girar_componente_angulo_seccionador(Point(poste_combinado['coordenadas_nuevas'][0]), union_A.iloc[0].geometry,distanciaR_Union,angulo_seccionador)
                                #SE RECUPERA EL PUNTO  POR LA DISTANCIA PARA LA ORIENTACION ORIGINAL EN LOS TRAMOS ANTIGUOS
                                if estado_iluminaria: 
                                    iluminaria_perpendicular = girar_componente_angulo_seccionador(Point(poste_combinado['coordenadas_nuevas'][0]), iluminaria_A.iloc[0].geometry,distanciaR_iluminaria,angulo_seccionador)
                                    capa_iluminarias_antiguas.at[int(iluminaria_A.iloc[0][0])-1,'geometry']= iluminaria_perpendicular

                                capa_seccionadoresF_antiguos.at[indexSF,'geometry'] =seccionador_perpendicular
                                capa_protectores_antiguos.at[int(protector_seccionador.iloc[0][0])-1,'geometry'] = protector_perpendicular
                                capa_unionesBT_antiguas.at[int(union_A.iloc[0][0])-1,'geometry'] =union_perpendicular 
                                capa_transformadores_antiguas.at[indexTA,'geometry']=transformador_perpendicular   
                                estado_iluminaria=False            
                        if estado_poste:
                            break     
    capa_protectores_antiguos.to_file("./movido/PROTECTORES_MOVIDO.shp") 
    capa_transformadores_antiguas.to_file("./movido/TRANSFORMADORES_MOVIDO.shp") 
    capa_seccionadoresF_antiguos.to_file("./movido/SECCIONADORES_F_MOVIDO.shp")  
    capa_unionesBT_antiguas.to_file("./movido/UNIONES_MOVIDO.shp")     
    capa_iluminarias_antiguas.to_file("./movido/ILUMINARIA_MOVIDA.shp") 



    #  FUNCION PARA MOVER RED CORRIENTE DE BAJA TENSION
def funcion_actualizar_bajantes_BTM(ruta_capa_lineas_BTM,shape_transformadoresV,shapefile_transformadoresM,shapefile_unionesA,shapefile_unionesM,shapefile_iluminariaA,shapefile_iluminariaM,shapefile_protecctoresA,shapefile_protecctoresM):
    # Cargar la capa de líneas 
    capa_lineas_BTM = gpd.read_file(ruta_capa_lineas_BTM)     
    capa_transformador_antiguo=gpd.read_file(shape_transformadoresV) 
    capa_protector_antiguo=gpd.read_file(shapefile_protecctoresA)   
    capa_union_antiguo=gpd.read_file(shapefile_unionesA)      
    capa_iluminaria_antiguo=gpd.read_file(shapefile_iluminariaA)    

    uniones_combinados =  funcion_combinar_geometrias_generales(shapefile_unionesA,shapefile_unionesM) 
    iluminarias_combinados = funcion_combinar_geometrias_generales(shapefile_iluminariaA, shapefile_iluminariaM)
    protecctores_combinados= funcion_combinar_geometrias_generales(shapefile_protecctoresA,shapefile_protecctoresM)
    transformadores_combinados=funcion_combinar_geometrias_generales(shape_transformadoresV,shapefile_transformadoresM)
    for index, linea_BTV in capa_lineas_BTM.iterrows():  
        if linea_BTV['SUBTIPO'] in [1,2,3,4,5,6,7,8,9]:#:#LINEAs BAJANTE BTA BIFASICA, QUE CONENTA DE LA UNION A LA ILUMINARIA
             
            linea_bt_bifasica =[] 
            for coord in linea_BTV.geometry.coords:  
                buffer_coord=Point(coord).buffer(0.10) #0.10 m
                transformador=[]
                protector=[]
                union=[]
                iluminaria=[]
                transformador=capa_transformador_antiguo[capa_transformador_antiguo['geometry'].within(buffer_coord)]
                protector=capa_protector_antiguo[capa_protector_antiguo['geometry'].within(buffer_coord)]
                union=capa_union_antiguo[capa_union_antiguo['geometry'].within(buffer_coord)]
                iluminaria=capa_iluminaria_antiguo[capa_iluminaria_antiguo['geometry'].within(buffer_coord)] 
                estado_encontrado=False
                if not transformador.empty:
                    for transformador_combinado in transformadores_combinados:
                        if transformador_combinado['id_antigua'] in transformador['OBJECTID'].values: 
                            linea_bt_bifasica.append(transformador_combinado['coordenadas_movidas'][0]) 
                            estado_encontrado=True
                            break
                elif not protector.empty and not estado_encontrado:
                    for protector_combinado in protecctores_combinados:
                        if protector_combinado['id_antigua'] in protector['OBJECTID'].values: 
                            linea_bt_bifasica.append(protector_combinado['coordenadas_movidas'][0])
                            estado_encontrado=True
                            break

                elif not union.empty and not estado_encontrado:
                    for union_combinado in uniones_combinados:
                        if union_combinado['id_antigua'] in union['OBJECTID'].values: 
                            linea_bt_bifasica.append(union_combinado['coordenadas_movidas'][0])
                            estado_encontrado=True
                            break

                elif not iluminaria.empty and not estado_encontrado:
                    for iluminaria_combinado in iluminarias_combinados:
                        if iluminaria_combinado['id_antigua'] in iluminaria['OBJECTID'].values: 
                            linea_bt_bifasica.append(iluminaria_combinado['coordenadas_movidas'][0])
                            estado_encontrado=True
                            break 
                if not estado_encontrado:
                    linea_bt_bifasica.append(coord)
            if len(linea_bt_bifasica)>1:
                capa_lineas_BTM.at[index, 'geometry'] = LineString(linea_bt_bifasica)
                #print("LINEA BAJA TRIFASICA CORREGIDA CON EL ID DE ",linea_BTV['OBJECTID'])
                linea_bt_bifasica=[] 
    capa_lineas_BTM.to_file("./movido/LINEAS_BAJA_TENSION_MOVIDO.shp")    
    
def funcion_correcion_bta_uniones(shapefile_lineabtA,shapefile_lineabtM,shapefile_union_A,shapefile_union_M):
    #capa_uniones_antiguas= gpd.read_file(shapefile_union_A) 
    capa_uniones_nuevas=gpd.read_file(shapefile_union_M)  
    capa_lineas_BTM=gpd.read_file(shapefile_lineabtM) 
    capa_lineas_BTA=gpd.read_file(shapefile_lineabtA) 
    uniones_combinados= funcion_combinar_geometrias_generales(shapefile_union_A,shapefile_union_M)  
    for indexbtm, lineaBTM in capa_lineas_BTM.iterrows():
        for indexla, lineaBTA in capa_lineas_BTA.iterrows():
            if lineaBTA['OBJECTID']==lineaBTM['OBJECTID']:  
                lineaBTM_corregida =[] 
                for coordBTA in lineaBTA.geometry.coords: 
                    for union_combinado in uniones_combinados:
                        if Point(union_combinado['coordenadas_antiguas'][0]).distance(Point(coordBTA))<0.10:
                            lineaBTM_corregida.append(union_combinado['coordenadas_movidas'][0])  
                            break 
                if len(lineaBTM_corregida)>1:
                    capa_lineas_BTM.at[indexbtm,'geometry']=LineString(lineaBTM_corregida) 
                    lineaBTM_corregida=[]
                    
                break 
    capa_lineas_BTM.to_file("./movido/LINEAS_BAJA_TENSION_MOVIDO.shp") 

def eliminar_lineas_infinitas(gdf, longitud_maxima):
    # Calcular la longitud de cada línea
    gdf['longitud'] = gdf['geometry'].apply(lambda geom: geom.length)

    # Filtrar líneas que exceden la longitud máxima
    gdf_filtrado = gdf[gdf['longitud'] <= longitud_maxima]

    # Eliminar la columna temporal 'longitud'
    gdf_filtrado = gdf_filtrado.drop(columns=['longitud'])

    return gdf_filtrado




# Función para redondear coordenadas
def round_coordinates(coord, precision=4):
    return (round(coord[0], precision), round(coord[1], precision))
    

# FUNCION PARA MOVER RED CORRIENTE DE ALTA TENSION 
def funcion_actualizar_lineaMT(ruta_capa_lineasMTA, shapefile_antiguos, shapefile_nuevos):    
    capa_lineasMTA = gpd.read_file(ruta_capa_lineasMTA) 
    capa_uniones_antiguas = gpd.read_file(shapefile_antiguos) 
    # Obtener las geometrías combinadas de los postes antiguos y nuevos
    postes_combinados = obtener_geometrias_combinadas(shapefile_antiguos, shapefile_nuevos) 
    #LOGICA DE RECORRER POR POSTE COMBINADO ANTIGUOS Y MOVIDOS
    max_length = capa_lineasMTA['geometry'].apply(lambda line: line.length).max()  
    print("------Longitud maxima es ---->>",max_length)
    longitud_maxima = max_length
    for registro in postes_combinados:# SE CORRIGE SOLO LOS POSTES COMBINADOS O RELACIONADOS POR IDS 
        for indx, aux_linea in capa_lineasMTA.iterrows():
            if aux_linea['SUBTIPO'] in [1,2,3]:  
                punto_buscar = Point(registro['coordenadas_antiguas'][0])#PUNTO POSTE ANTIGUO 
                distancia = punto_buscar.distance(aux_linea['geometry']) 
                #buffer_poste = Point(registro['coordenadas_antiguas'][0]).buffer(1.50)

                if distancia < 1.5:#DISTANCIA DE VERTICES LINEA Y POSTES ANTIGUAS  
                    nueva_linea_coords = actualizar(aux_linea['geometry'], registro['coordenadas_antiguas'], registro['coordenadas_nuevas'])
                    capa_lineasMTA.at[indx, 'geometry'] = LineString(nueva_linea_coords)#ACTUALIZANDO LINEA BTA  
                    nueva_linea_coords =[]
        
                
     
    # Guardar la capa de líneas actualizada en un nuevo archivo shapefile
    capa_lineasMTA.to_file("./movido/LINEAS_MEDIA_TENSION_MOVIDO.shp")
    capa_lineasmtm_infinito= gpd.read_file("./movido/LINEAS_MEDIA_TENSION_MOVIDO.shp") 
    capa_lineasMTM_filtradas =eliminar_lineas_infinitas(capa_lineasmtm_infinito, longitud_maxima)
    capa_lineasMTM_filtradas.to_file("./movido/LINEAS_MEDIA_TENSION_MOVIDO.shp")
 
def actualizar_coordenadas_bajatension(ruta_capa_lineasMTA,ruta_capa_lineasMTM,shape_postesA,shape_postesM, ruta_capa_lineas_BTV,shapefile_unionesA,shapefile_transformadores_M,shapefile_iluminariaA):
    # Cargar la capa de líneas 
    capa_lineas_BT = gpd.read_file(ruta_capa_lineas_BTV)   
    capa_iluminarias_A = gpd.read_file(shapefile_iluminariaA) 
    capa_lineas_MTM = gpd.read_file(ruta_capa_lineasMTM)
    capa_lineas_MTA = gpd.read_file(ruta_capa_lineasMTA)  
    capa_transformadores_MTM = gpd.read_file(shapefile_transformadores_M)   
    capa_unionesA = gpd.read_file(shapefile_unionesA)    
    postes_combinados = obtener_geometrias_combinadas(shape_postesA,shape_postesM)  #funcion_agrupar_unionesbt_antiguas_movidas(shapefile_UnionesAntiguos,shapefile_UnionesMovidas)
    distanciaR_vertice=1.40 
    distanciaR_iluminaria=1.75
    for indexlbta, lineabta in capa_lineas_BT.iterrows(): 
        new_lineaBTM=[]
        lineaMTM_perpendicular=[]
         
        if lineabta['SUBTIPO'] in [1,2,3]:
            #recoore coordenadas de lina bta en transformador
            for coordBTA in lineabta.geometry.coords:
                for poste_combinado in postes_combinados:
                    if Point(coordBTA).distance(Point(poste_combinado['coordenadas_antiguas'][0])) <1.90:
                        diffCoordX = coordBTA[0]- poste_combinado['coordenadas_antiguas'][0][0]
                        diffCoordY = coordBTA[1]- poste_combinado['coordenadas_antiguas'][0][1]
                        vertice_diferencia=[(poste_combinado['coordenadas_nuevas'][0][0]+diffCoordX, poste_combinado['coordenadas_nuevas'][0][1]+diffCoordY)]     
                        #LINEAS MT MOVIDAS EN POSTE NUEVO COMBINADO 
                        lineasMTM_poste_combinado= capa_lineas_MTM[(capa_lineas_MTM.distance(Point(poste_combinado['coordenadas_nuevas'][0])).le(1.80)) & (capa_lineas_MTM['SUBTIPO'].isin([1,2,3]))] #RECUPERANDO LINEA MTM  EN POSTE
                        
                        if not lineasMTM_poste_combinado.empty: 
                            vertice_perpendicular=[] 
                            lineaMTM_perpendicular=[]
                            if len(lineasMTM_poste_combinado)>1:
                                lineaMTM_perpendicular = encontrar_linea_mas_cercana(lineasMTM_poste_combinado,Point(coordBTA))#en base a la coordenada                             
                            elif len(lineasMTM_poste_combinado)==1: 
                                lineaMTM_perpendicular= lineasMTM_poste_combinado.iloc[0].geometry
                            lado_vertice_A, posicion_linea= get_line_point_relative_position_correcion(Point(coordBTA), lineaMTM_perpendicular,Point(poste_combinado['coordenadas_nuevas'][0]) )  
                            vertice_perpendicular = move_point_perpendicular_to_line(Point(poste_combinado['coordenadas_nuevas'][0]),lineaMTM_perpendicular, Point(vertice_diferencia),distanciaR_vertice,lado_vertice_A,posicion_linea)
                            lado_antiguo,posicionlinea1 = get_line_point_relative_position_correcion(Point(vertice_diferencia), lineaMTM_perpendicular, Point(poste_combinado['coordenadas_nuevas'][0]))
                            lado_nuevo,posicionlinea2 = get_line_point_relative_position_correcion(vertice_perpendicular, lineaMTM_perpendicular, Point(poste_combinado['coordenadas_nuevas'][0]))
                            
                            angulo_vertice=angle_seccionador_poste(Point(poste_combinado['coordenadas_nuevas'][0]),vertice_perpendicular)
                            if lado_antiguo!=lado_nuevo:  
                                angulo_vertice = (angulo_vertice + 180) % 360  
                            else:
                                angulo_vertice= angulo_vertice 

                            vertice_perpendicular = girar_componente_angulo_seccionador(Point(poste_combinado['coordenadas_nuevas'][0]), Point(coordBTA),distanciaR_vertice,angulo_vertice)
                            new_lineaBTM.append((vertice_perpendicular.x,vertice_perpendicular.y))   

                            unionA_BTA = capa_unionesA[capa_unionesA.geometry.distance(Point(coordBTA)).le(0.20)] 
                            angulo_vertice=angle_seccionador_poste(Point(poste_combinado['coordenadas_nuevas'][0]),vertice_perpendicular)
                            
                            #-------------------uniones  
                            for index_union, unionA in unionA_BTA.iterrows():
                                if not unionA.empty: 

                                    capa_unionesA.at[index_union,'geometry']=vertice_perpendicular

                                    #-----BUSCANDO ILUMINARIAS CERCA DE UNION   
                                    buffer_union=unionA.geometry.buffer(0.45) 
                                    iluminaria_A= capa_iluminarias_A[capa_iluminarias_A.geometry.within(buffer_union)]

                                    for indexIL,  iluminaria in iluminaria_A.iterrows():
                                        diffXIl = iluminaria['geometry'].coords[0][0]- poste_combinado['coordenadas_antiguas'][0][0]
                                        diffYIl = iluminaria['geometry'].coords[0][1]- poste_combinado['coordenadas_antiguas'][0][1]
                                        iluminaria_diferencia=[(poste_combinado['coordenadas_nuevas'][0][0]+diffXIl,poste_combinado['coordenadas_nuevas'][0][1]+diffYIl)]  

                                        #ANGULO PERPENDICULAR SEGUN LA ORIENTACION DE VERTICE Y LIENA O POSTE ANTIGUO  
                                        vertice_iluminaria = girar_componente_angulo_seccionador(Point(poste_combinado['coordenadas_nuevas'][0]), iluminaria_A.geometry,distanciaR_iluminaria,angulo_vertice)
                                        capa_iluminarias_A.at[indexIL,'geometry']= vertice_iluminaria 
                                        

                        elif  lineasMTM_poste_combinado.empty:# GUARDANDO LINEAS Y UNIONES APLICANDO DIFERENCIAS , SIN LINEA MTM
                            new_lineaBTM.append((vertice_diferencia[0][0],vertice_diferencia[0][1])) 
                            unionA_BTA2 = capa_unionesA[capa_unionesA.geometry.distance(Point(coordBTA)).le(0.15)]   
                            for index_union2, unionA2 in unionA_BTA2.iterrows():
                                if not unionA2.empty:
                                    capa_unionesA.at[index_union2,'geometry']=Point(vertice_diferencia)
                                    #-----BUSCANDO ILUMINARIAS CERCA DE UNION
                                    iluminaria_A2= capa_iluminarias_A[capa_iluminarias_A.distance(Point(poste_combinado['coordenadas_antiguas'][0])).le(1.80)]
                                    for indexl, iluminaria in iluminaria_A2.iterrows():
                                        diffXilu=iluminaria['geometry'].coords[0][0] - poste_combinado['coordenadas_antiguas'][0][0]
                                        diffYilu=iluminaria['geometry'].coords[0][1] - poste_combinado['coordenadas_antiguas'][0][1] 
                                        #SE RECUPERA EL PUNTO  POR LA DISTANCIA PARA LA ORIENTACION ORIGINAL EN LOS TRAMOS ANTIGUOS
                                        iluminaria_diferencia=[(poste_combinado['coordenadas_nuevas'][0][0]+diffXilu,poste_combinado['coordenadas_nuevas'][0][1]+diffYilu)] 
                                        capa_iluminarias_A.at[indexl,'geometry']= Point(iluminaria_diferencia)
                        break
            if len(new_lineaBTM)>1:
                capa_lineas_BT.at[indexlbta,'geometry']= LineString(new_lineaBTM)
                new_lineaBTM=[] 
    capa_lineas_BT.to_file("./movido/LINEAS_BAJA_TENSION_MOVIDO.shp") 
    capa_unionesA.to_file("./movido/UNIONES_MOVIDO.shp") 
    capa_iluminarias_A.to_file("./movido/ILUMINARIA_MOVIDA.shp")




 
def  funcion_actualizar_lineaMTM_bajante(ruta_capa_lineasMovidas, shapefile_antiguos, shapefile_nuevos,shapefile_seccionadoresF_A,shapefile_seccionadoresF_M,shapefile_transformadoresA,shapefile_transformadoresM):
    # Cargar la capa de líneas   
    # Cargar la capa de líneas   
    capa_lineasMovidas = gpd.read_file(ruta_capa_lineasMovidas) 
    capa_poste_antiguo= gpd.read_file(shapefile_antiguos)
    capa_seccionador_antiguo= gpd.read_file(shapefile_seccionadoresF_A)
    capa_transformador_antiguo= gpd.read_file(shapefile_transformadoresA)
    #capa_union_antiguo= gpd.read_file(shapefile_transformadoresA)
    
    #uniones_combinados= funcion_combinar_geometrias_generales(shapefile_uniones_antiguos, shapefile_uniones_nuevos)
    seccionadores_f_combinados= funcion_combinar_geometrias_generales(shapefile_seccionadoresF_A,shapefile_seccionadoresF_M)
    transformadores_combinados= funcion_combinar_geometrias_generales(shapefile_transformadoresA,shapefile_transformadoresM) 
    # Obtener las geometrías combinadas de los postes antiguos y nuevos 
    geometrias_combinadas = obtener_geometrias_combinadas(shapefile_antiguos, shapefile_nuevos) 
    for indx, aux_linea in capa_lineasMovidas.iterrows(): 
        if aux_linea['SUBTIPO'] in [4,5,6]:
            #print("----MOVIENDO TRAMOS BAJANTES DE MT MOVIDAS---")
            lineaBajante=[]  
            for coord in aux_linea.geometry.coords:  
                estado_coord=False
                buffer_coord=Point(coord).buffer(0.10) #0.10 m
                vertice_new_BT=[]
                posteAE =[] 
                seccionadorAE =[]
                transformadorAE =[]
                posteAE = capa_poste_antiguo[capa_poste_antiguo['geometry'].within(buffer_coord)] 
                seccionadorAE = capa_seccionador_antiguo[capa_seccionador_antiguo['geometry'].within(buffer_coord)] 
                transformadorAE = capa_transformador_antiguo[capa_transformador_antiguo['geometry'].within(buffer_coord)]
                #unionAE = capa_union_antiguo[capa_union_antiguo['geometry'].within(buffer_coord)]
                #COORDENADA EN POSTE
                if not posteAE.empty: 
                    #Se usa aproximacion en poste con vertice 
                    for poste_combiando in geometrias_combinadas:# SE CORRIGE SOLO LOS POSTES COMBINADOS O RELACIONADOS POR IDS 

                        if  (poste_combiando['id_antiguo'] in posteAE['OBJECTID'].values) and Point(coord).distance(Point(poste_combiando['coordenadas_antiguas'][0])) <0.10: 
                            vertice_new_BT= poste_combiando['coordenadas_nuevas'][0]
                            estado_coord=True
                            break
                    
                elif not seccionadorAE.empty and not estado_coord:
                    #COORDENADA EN SECCIONADOR 
                        for seccionador_combiando in seccionadores_f_combinados:# SE CORRIGE SOLO LOS POSTES COMBINADOS O RELACIONADOS POR IDS 
                            if  (seccionador_combiando['id_antigua'] in seccionadorAE['OBJECTID'].values) and Point(coord).distance(seccionadorAE.iloc[0].geometry) <0.10: 
                                #lineaBajante.append(seccionador_combiando['coordenadas_movidas'][0])
                                vertice_new_BT=seccionador_combiando['coordenadas_movidas'][0]
                                estado_coord=True 
                                break
                if not transformadorAE.empty and not estado_coord:
                    for transformador_combinado in transformadores_combinados:
                        if (transformador_combinado['id_antigua'] in transformadorAE['OBJECTID'].values) and Point(coord).distance(transformadorAE.iloc[0].geometry) <0.10 : 
                            #lineaBajante.append(transformador_combinado['coordenadas_movidas'][0])
                            vertice_new_BT=transformador_combinado['coordenadas_movidas'][0]
                            estado_coord=True 
                            break  
                if not estado_coord:
                    lineaBajante.append(coord)
                elif estado_coord:
                    lineaBajante.append(vertice_new_BT)
                    vertice_new_BT=[]
            if len(lineaBajante)==2 :
                capa_lineasMovidas.at[indx, 'geometry'] = LineString(lineaBajante)
                #print("LINEA MEDIA TENSION TRIFASICA CORREGIDA CON EL ID DE ",aux_linea['OBJECTID'])
                lineaBajante=[]   
        
    # Guardar la capa de líneas actualizada en un nuevo archivo shapefile
    capa_lineasMovidas.to_file("./movido/LINEAS_MEDIA_TENSION_MOVIDO.shp") 

if __name__ == '__main__':
    # CAPAS ANTIGUAS A MOVER 
    TRANSFORMADORES_ANTIGUO='./tramos/TRANSFORMADORES_ANTIGUOS.shp' 
    SECCIONADORES_ANTIGUOS = './tramos/SECCIONADORES_ANTIGUOS.shp'#REFERENCIA DE POSTES NUEVOS
    SECCIONADORES_F_ANTIGUO = './tramos/SECCIONADOR_F_ANTIGUOS.shp'#REFERENCIA DE POSTES NUEVOS
    POSTES_ANTIGUOS = './tramos/POSTE_ANTIGUO.shp'#REFERENCIA DE POSTES NUEVOS
    POSTES_NUEVOS = './tramos/POSTE_NUEVO.shp' 
    UNIONES_ANTIGUAS = './tramos/UNIONES_ANTIGUAS.shp'
    ILUMINARIAS_ANTIGUAS ='./tramos/ILUMINARIA_ANTIGUO.shp' 
    PROTECCTORES_ANTIGUOS= './tramos/PROTECCTORES_ANTIGUOS.shp'
    LINEA_MEDIA_TENSIÓN = './tramos/LINEAS_MEDIA_TENSION_ANTIGUAS.shp'
    LINEA_MEDIA_TENSIÓN_SUB = './tramos/LINEAS_MEDIA_TENSION_SUB_ANTIGUAS.shp' 
    LINEA_BAJA_TENSION_ANTIGUO='./tramos/LINEAS_BAJA_TENSION_ANTIGUAS.shp' 
    #-CAPAS MOVIDOS O CORREGIDASvertice_iluminaria =  mover_iluminaria_perpendicular_to_poste(Point(poste_combinado['coordenadas_nuevas'][0]), Point(iluminaria_diferencia),distanciaR_iluminaria)
    MEDIA_TENSION_MOVIDO='./movido/LINEAS_MEDIA_TENSION_MOVIDO.shp'  
    BAJA_TENSION_MOVIDO='./movido/LINEAS_BAJA_TENSION_MOVIDO.shp' 
    ILUMINARIA_MOVIDO='./movido/ILUMINARIA_MOVIDA.shp'  
    MEDIA_TENSION_SUB_MOVIDO='./movido/LINEAS_MEDIA_TENSION_SUB.shp' 
    UNIONES_BAJA_TENSION_MOVIDO='./movido/UNIONES_MOVIDO.shp'
    TRANSFORMADORES_MOVIDO='./movido/TRANSFORMADORES_MOVIDO.shp'
    PROTECTORES_MOVIDO='./movido/PROTECTORES_MOVIDO.shp'
    SECCIONADORES_F_MOVIDA = './movido/SECCIONADORES_F_MOVIDO.shp'#REFERENCIA DE POSTES NUEVOS
    #INICIO DE TIEMPO
    inicio = time.time()
    #MOVIENDO TRAMOS 3 EN MT ANTIGUAS
    funcion_actualizar_lineaMT(LINEA_MEDIA_TENSIÓN,POSTES_ANTIGUOS,POSTES_NUEVOS)   
    funcion_actualizar_seccionadores_postes(POSTES_ANTIGUOS,POSTES_NUEVOS,SECCIONADORES_ANTIGUOS,MEDIA_TENSION_MOVIDO) 
    funcion_actualizar_seccionadorTransformadorF_postesA(SECCIONADORES_F_ANTIGUO,TRANSFORMADORES_ANTIGUO,PROTECCTORES_ANTIGUOS,POSTES_ANTIGUOS,POSTES_NUEVOS,LINEA_MEDIA_TENSIÓN,MEDIA_TENSION_MOVIDO,LINEA_BAJA_TENSION_ANTIGUO,UNIONES_ANTIGUAS,ILUMINARIAS_ANTIGUAS)
    actualizar_coordenadas_bajatension(LINEA_MEDIA_TENSIÓN,MEDIA_TENSION_MOVIDO,POSTES_ANTIGUOS,POSTES_NUEVOS,LINEA_BAJA_TENSION_ANTIGUO,UNIONES_BAJA_TENSION_MOVIDO,TRANSFORMADORES_MOVIDO,ILUMINARIA_MOVIDO) 
    funcion_actualizar_lineaMTM_bajante(MEDIA_TENSION_MOVIDO, POSTES_ANTIGUOS,POSTES_NUEVOS,SECCIONADORES_F_ANTIGUO,SECCIONADORES_F_MOVIDA,TRANSFORMADORES_ANTIGUO,TRANSFORMADORES_MOVIDO) 
    funcion_actualizar_bajantes_BTM(BAJA_TENSION_MOVIDO,TRANSFORMADORES_ANTIGUO,TRANSFORMADORES_MOVIDO,UNIONES_ANTIGUAS,UNIONES_BAJA_TENSION_MOVIDO,ILUMINARIAS_ANTIGUAS,ILUMINARIA_MOVIDO,PROTECCTORES_ANTIGUOS,PROTECTORES_MOVIDO) 
    #funcion_correcion_bta_uniones(LINEA_BAJA_TENSION_ANTIGUO, BAJA_TENSION_MOVIDO,UNIONES_ANTIGUAS,UNIONES_BAJA_TENSION_MOVIDO)

    final = time.time()
    print(f"Tiempo de ejecucion en minutos: {(round(final - inicio, 1)/60)} segundos.")
    print("----CANTIDAD TOTALES : ",total_componentes_poste,":--: PORCENTAJE MOVIDOS : ",((total_movidos*100)/total_componentes_poste),"%" )
    print("---Cantidad movidos : ",total_movidos,"---OBJECTIDS-",lista_componentes_movidos)
    print("--Cantidad faltantes : ",total_faltantes,"---OBJECTIDS-",lista_componentes_faltantes)
    lista_no_aplicados=[]
    lista_no_aplicados2=[]
 
    
    for componente in lista_componentes_postes: 
        if componente not in  lista_componentes_movidos:
            lista_no_aplicados.append(componente)

    for faltante in lista_no_aplicados:  
        if faltante not in  lista_componentes_faltantes:
            lista_no_aplicados2.append(faltante) 
    
    print("--Cantidad no APLICADOS : ",len(lista_no_aplicados2),"---OBJECTIDS-",lista_no_aplicados2)
    